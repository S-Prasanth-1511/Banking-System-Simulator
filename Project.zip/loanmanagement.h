#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <ctime>
#include <cstdlib>
#include <forward_list>
#include <vector>
#include <algorithm>
#include <stdexcept>
#include <memory>
#include <stack>

using namespace std;

struct AccountDetails {
    long long int account_number;
    string account_holder;
    string address;
    string phone_number;
    string PAN_number;
    string type;
    double balance;
    string date_of_creation;
    string date_of_closer;
    string status;
    int cibil_score;
    int loan_id;
    double interest_rate;
};

struct LoanDetails {
    int loan_id;
    long long int account_number;
    string type;
    double loan_amount;
    double interest_rate;
    int term;
    string date;
    string status;
};


struct AVLNode {
    long long int account_number;
    AVLNode* left;
    AVLNode* right;
    int height;

    AVLNode(long int acc_num)
        : account_number(acc_num), left(nullptr), right(nullptr), height(1) {}
};

class AVLTree {
private:
    AVLNode* root;

    int height(AVLNode* node) {
        return node ? node->height : 0;
    }

    int getBalance(AVLNode* node) {
        return node ? height(node->left) - height(node->right) : 0;
    }

    AVLNode* rightRotate(AVLNode* y) {
        AVLNode* x = y->left;
        AVLNode* T2 = x->right;

        x->right = y;
        y->left = T2;

        y->height = max(height(y->left), height(y->right)) + 1;
        x->height = max(height(x->left), height(x->right)) + 1;

        return x;
    }

    AVLNode* leftRotate(AVLNode* x) {
        AVLNode* y = x->right;
        AVLNode* T2 = y->left;

        y->left = x;
        x->right = T2;

        x->height = max(height(x->left), height(x->right)) + 1;
        y->height = max(height(y->left), height(y->right)) + 1;

        return y;
    }

    AVLNode* insert(AVLNode* node, long int account_number) {
        if (!node)
            return new AVLNode(account_number);

        if (account_number < node->account_number)
            node->left = insert(node->left, account_number);
        else if (account_number > node->account_number)
            node->right = insert(node->right, account_number);
        else
            return node; // Duplicate account numbers are not allowed

        node->height = 1 + max(height(node->left), height(node->right));

        int balance = getBalance(node);

        if (balance > 1 && account_number < node->left->account_number)
            return rightRotate(node);

        if (balance < -1 && account_number > node->right->account_number)
            return leftRotate(node);

        if (balance > 1 && account_number > node->left->account_number) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }

        if (balance < -1 && account_number < node->right->account_number) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

        return node;
    }

    bool search(AVLNode* node, long int account_number) {
        if (!node)
            return false;

        if (account_number == node->account_number)
            return true;
        else if (account_number < node->account_number)
            return search(node->left, account_number);
        else
            return search(node->right, account_number);
    }

    void inOrder(AVLNode* root) {
        if (root != nullptr) {
            inOrder(root->left);
            cout << root->account_number << " ";
            inOrder(root->right);
        }
    }

public:
    AVLTree() : root(nullptr) {}

    void insert(long int account_number) {
        root = insert(root, account_number);
    }

    bool search(long int account_number) {
        return search(root, account_number);
    }

    void inOrder() {
        inOrder(root);
    }
};

class ownloan{
vector<LoanDetails> Loans;
public:
    void generateLoanPortfolioReport() {
        cout << "Loan Portfolio Report" << endl;
        cout << "---------------------" << endl;
        cout << "Loan ID\tAccount Number\tType\tLoan Amount\tInterest Rate\t\tTerm\t\tDate\t\tStatus" << endl;

        for (const auto& loan : Loans) {
            cout << loan.loan_id << "\t" << loan.account_number << "\t\t" << loan.type << "\t" << loan.loan_amount << "\t\t"
                 << loan.interest_rate << "\t\t" << loan.term << "\t\t" << loan.date << "\t" << loan.status << endl;
        }
    }

    ownloan() {
    ifstream loanFile("loandetails.csv");

    if (!loanFile.is_open()) {
        cerr << "Error: Unable to open loan details file." << endl;
        throw runtime_error("Unable to open loan details file.");
    }

    LoanDetails newLoan;

    // Read loan details from the file
    string line;
    while (getline(loanFile, line)) {
        stringstream ss(line);
        string token;

        // Parse each token separated by comma
        getline(ss, token, ',');
        try {
            newLoan.loan_id = stoi(token); // Convert string to integer
        } catch (const std::invalid_argument& ia) {
            continue;
        }

        getline(ss, token, ',');
        newLoan.account_number = stoll(token);

        getline(ss, newLoan.type, ',');

        getline(ss, token, ',');
        newLoan.loan_amount = stod(token);

        getline(ss, token, ',');
        newLoan.interest_rate = stod(token);

        getline(ss, token, ',');
        newLoan.term = stoi(token);

        getline(ss, newLoan.status, ',');

        getline(ss, newLoan.date);

        // Add the loan to the Loans vector
        Loans.push_back(newLoan);
    }

    loanFile.close();
}
};
class loan {
protected:
    AVLTree accounts;
    int loan_id;
    double loan_amount;
    string type;
    string start_date;
    string status;
    long int account_number;
    int term;
    vector<int> loan_ids;
    int cust_id, acct_id;
    string account_details_file = "accountDetails.csv";
    string loan_details_file = "loandetails.csv";


public:
    mutable vector<LoanDetails> loans;
    double interest_rate;
    loan(long int account_number, int term);
    friend void generateLoanPortfolioReport(const loan& loan);
    virtual int create_loan(const long int& account_number, int term);
    void writeLoanDetailsToCSV(string type, int term) const;
    void write_loan_details_to_file() const;
    string get_loan_file_name() const;
    void view_loan_details(int loan_id);

    vector<LoanDetails> getloans() const {
        return loans;
    }
};

loan::loan(long int account_number, int term) {
    ifstream accountFile("accountDetails.csv");
    this->term = term;
    if (!accountFile.is_open()) {
        cerr << "Error: Unable to open account details file." << endl;
        throw runtime_error("Unable to open account details file.");
    }

    string line;
    getline(accountFile, line); // Skip header
    while (getline(accountFile, line)) {
        stringstream ss(line);
        string data;
        AccountDetails account;
        getline(ss, data, ',');
        account.account_number = stoll(data);
        getline(ss, account.type, ',');
        getline(ss, account.status, ',');

        accounts.insert(account.account_number);
    }
    accountFile.close();

    if (!accounts.search(account_number)){
        cout<<"Account Number Not Found. Please Create a account in our bank.\n";
        exit(1);
    }

    ifstream loan_file(loan_details_file);
    if (!loan_file.is_open()) {
        cerr << "Error: Unable to open loan details file." << endl;
        throw runtime_error("Unable to open loan details file.");
    }

    getline(loan_file, line);
    getline(loan_file, line);

    while (getline(loan_file, line)) {
        stringstream ss(line);
        string data;

        getline(ss, data, ',');
        try {
            loan_id = stoi(data); // Convert string to integer
        } catch (const std::invalid_argument& ia) {
            continue;
        }
        loan_ids.push_back(loan_id);
    }

    loan_file.close();
}



int loan::create_loan(const long int& account_number, int term) {
    loan_id = rand() % 10000 + 1;

    while (find(loan_ids.begin(), loan_ids.end(), loan_id) != loan_ids.end()) {
        loan_id = rand() % 10000 + 1;
    }

    this->loan_id = loan_id;
    this->account_number = account_number;

    time_t now = time(0);
    char* date_time = ctime(&now);
    start_date = string(date_time);

    cout << "Enter Loan amount: ";
    cin >> this->loan_amount;

    status = "active";

    this->term = term;
    return this->loan_id;
}

void loan::writeLoanDetailsToCSV(string type, int term) const {
    ofstream loanFile("loandetails.csv", ios::app);

    if (!loanFile.is_open()) {
        cerr << "Error: Unable to open loan details file." << endl;
        throw runtime_error("Unable to open loan details file.");
    }

    loanFile << loan_id << "," << account_number << "," << type << "," << loan_amount << "," << interest_rate << "," << term << ",active," << start_date << endl;

    loanFile.close();

    // Add loan details to the loans vector
    shared_ptr<LoanDetails> newLoan(new LoanDetails); // Allocate memory for the new loan
    newLoan->loan_id = loan_id;
    newLoan->account_number = account_number;
    newLoan->type = type;
    newLoan->loan_amount = loan_amount;
    newLoan->interest_rate = interest_rate;
    newLoan->term = term;
    newLoan->date = start_date;
    newLoan->status = "active";

    loans.push_back(*newLoan); // Push the new loan into the vector

    // Update the loan details file
    write_loan_details_to_file();
}

void loan::write_loan_details_to_file() const {
    string filename = get_loan_file_name();
    ofstream loan_file(filename);

    if (!loan_file.is_open()) {
        cerr << "Error: Unable to create loan file." << endl;
        return;
    }

    loan_file << "1\nLoan ID: " << loan_id << "\n";
    loan_file << "Account Number: " << account_number << "\n";
    loan_file << "Loan Amount: " << loan_amount << "\n";
    loan_file << "Loan Type: " << type << "\n";
    loan_file << "Interest Rate: " << interest_rate << "%" << "\n";
    loan_file << "Term:" << term << "\n";
    loan_file << "Start Date: " << start_date << "\n";
    loan_file << "Status: " << status << "\n";
    loan_file<<0<<","<<loan_amount<<start_date;
    loan_file.close();
}

string loan::get_loan_file_name() const {
    return "loan_" + to_string(loan_id) + ".txt";
}


void loan::view_loan_details(int loan_id) {
    string filename = "loan_" + to_string(loan_id) + ".txt";
    ifstream loan_file(filename);

    if (!loan_file.is_open()) {
        cerr << "Error: Loan file not found." << endl;
        return;
    }

    string line;
    while (getline(loan_file, line)) {
        cout << line << endl;
    }
    loan_file.close();
}

class CarLoan : public loan {
public:
    CarLoan(long int account_number, int term) : loan(account_number, term) {}
    int create_loan(const long int& account_number, int term) override {
        int loan_id = loan::create_loan(account_number, term);
        this->type = "Car";

        int ch;
        x:{
            cout << "The interest rates available are 1)5%\t2)6.5%\t3)7%\t4)8.79%\t5)10%" << endl;
            cout << "Enter the interest rate choice: ";
            cin >> ch;
            switch (ch) {
                case 1:
                    this->interest_rate = 5.0;
                    break;
                case 2:
                    this->interest_rate = 6.5;
                    break;
                case 3:
                    this->interest_rate = 7.0;
                    break;
                case 4:
                    this->interest_rate = 8.79;
                    break;
                case 5:
                    this->interest_rate = 10.0;
                    break;
                default:
                    cout << "Invalid choice!" << endl;
                    goto x;
            }
        }

        writeLoanDetailsToCSV(this->type, term);

        view_loan_details(loan_id);
        return loan_id;
    }
};

class HomeLoan : public loan {
public:
    HomeLoan(long int account_number, int term) : loan(account_number, term) {}
    int create_loan(const long int& account_number, int term) override {
        int loan_id = loan::create_loan(account_number, term);
        this->type = "Home";

        int ch;
        x:{
            cout << "The interest rates available are 1)6%\t2)7%\t3)8%\t4)9%\t5)10%" << endl;
            cout << "Enter the interest rate choice: ";
            cin >> ch;
            switch (ch) {
                case 1:
                    this->interest_rate = 6.0;
                    break;
                case 2:
                    this->interest_rate = 7.0;
                    break;
                case 3:
                    this->interest_rate = 8.0;
                    break;
                case 4:
                    this->interest_rate = 9.0;
                    break;
                case 5:
                    this->interest_rate = 10.0;
                    break;
                default:
                    cout << "Invalid choice!" << endl;
                    goto x;
            }
        }

        writeLoanDetailsToCSV(this->type, term);

        view_loan_details(loan_id);
        return loan_id;
    }
};

class EducationalLoan : public loan {
public:
    EducationalLoan(long int account_number, int term) : loan(account_number, term) {}
    int create_loan(const long int& account_number, int term) override {
        int loan_id = loan::create_loan(account_number, term);
        this->type = "Educational";

        int ch;
        x:{
            cout << "The interest rates available are 1)5%\t2)6.5%\t3)7%" << endl;
            cout << "Enter the interest rate choice: ";
            cin >> ch;
            switch (ch) {
                case 1:
                    this->interest_rate = 5.0;
                    break;
                case 2:
                    this->interest_rate = 6.5;
                    break;
                case 3:
                    this->interest_rate = 7.0;
                    break;
                default:
                    cout << "Invalid choice!" << endl;
                    goto x;
            }
        }

        writeLoanDetailsToCSV(this->type, term);

        view_loan_details(loan_id);
        return loan_id;
    }
};

class AgriculturalLoan : public loan {
public:
    AgriculturalLoan(long int account_number, int term) : loan(account_number, term) {}
    int create_loan(const long int& account_number, int term) override {
        int loan_id = loan::create_loan(account_number, term );
        this->type = "Agricultural";

        int ch;
        x:{
            cout << "The interest rates available are 1)5%\t2)6.5%\t3)7.3%\t4)8.79%\t5)9.76%" << endl;
            cout << "Enter the interest rate choice: ";
            cin >> ch;
            switch (ch) {
                case 1:
                    this->interest_rate = 5.0;
                    break;
                case 2:
                    this->interest_rate = 6.5;
                    break;
                case 3:
                    this->interest_rate = 7.3;
                    break;
                case 4:
                    this->interest_rate = 8.79;
                    break;
                case 5:
                    this->interest_rate = 9.76;
                    break;
                default:
                    cout << "Invalid choice!" << endl;
                    goto x;
            }
        }

        writeLoanDetailsToCSV(this->type, term);
        view_loan_details(loan_id);
        return loan_id;
    }
};

class GoldLoan : public loan {
public:
    GoldLoan(long int account_number, int term) : loan(account_number, term) {}
    int create_loan(const long int& account_number, int term) override {
        int loan_id = loan::create_loan(account_number,term);
        this->type = "Gold";

        int ch;
        x:{
            cout << "The interest rates available are 1)6%\t2)7%\t3)8%\t4)9%\t5)10%" << endl;
            cout << "Enter the interest rate choice: ";
            cin >> ch;
            switch (ch) {
                case 1:
                    this->interest_rate = 6.0;
                    break;
                case 2:
                    this->interest_rate = 7.0;
                    break;
                case 3:
                    this->interest_rate = 8.0;
                    break;
                case 4:
                    this->interest_rate = 9.0;
                    break;
                case 5:
                    this->interest_rate = 10.0;
                    break;
                default:
                    cout << "Invalid choice!" << endl;
                    goto x;
            }
        }
        writeLoanDetailsToCSV(this->type, term);
        view_loan_details(loan_id);
        return loan_id;
    }
};

class IntGraph {
private:
    vector<double> interestRates = {5.0, 6.5, 7.0, 8.79, 10.0, 6.0, 8.0, 9.0, 7.3, 9.76};
    vector<vector<int>> adjMat = {
        {0, 1, 0, 0, 1, 0, 0, 0, 0, 0},
        {1, 0, 1, 0, 0, 1, 0, 0, 0, 0},
        {0, 1, 0, 1, 0, 0, 1, 1, 0, 0},
        {0, 0, 1, 0, 0, 0, 0, 1, 1, 0},
        {1, 0, 0, 0, 0, 1, 0, 0, 0, 1},
        {0, 1, 0, 0, 1, 0, 1, 0, 0, 0},
        {0, 0, 1, 0, 0, 1, 0, 1, 0, 0},
        {0, 0, 1, 1, 0, 0, 1, 0, 1, 0},
        {0, 0, 0, 1, 0, 0, 0, 1, 0, 1},
        {0, 0, 0, 0, 1, 0, 0, 0, 1, 0}
    };
    vector<vector<int>> weights;

public:
    IntGraph() : weights(10, vector<int>(10, 0)) {}

    void addEdge(double interestRate) {
        auto it = find(interestRates.begin(), interestRates.end(), interestRate);
        if (it == interestRates.end()) {
            cout << "No Interest Rate available!\n";
            return;
        }
        int ind = distance(interestRates.begin(), it);
        for (int i = 0; i < 10; ++i) {
            if (i == ind) {
                continue;
            }
            if (adjMat[ind][i] == 1 || adjMat[i][ind] == 1) {
                weights[ind][i] += 1;
                weights[i][ind] += 1;
            }
        }
    }

    void topologicalSortUtil(int v, vector<bool>& visited, stack<int>& Stack) {
        visited[v] = true;
        for (int i = 0; i < 10; ++i) {
            if (adjMat[v][i] && !visited[i]) {
                topologicalSortUtil(i, visited, Stack);
            }
        }
        Stack.push(v);
    }

    void topologicalSort() {
        stack<int> Stack;
        vector<bool> visited(10, false);
        for (int i = 0; i < 10; ++i) {
            if (!visited[i]) {
                topologicalSortUtil(i, visited, Stack);
            }
        }
        while (!Stack.empty()) {
            cout << interestRates[Stack.top()] << " ";
            Stack.pop();
        }
        cout << endl;
    }

    void floydWarshall() {

        int INF=INT_MAX;
        weights = {
        {0, 3, INF, INF, 1, INF, INF, INF, INF, INF},
        {3, 0, 4, INF, INF, 6, INF, INF, INF, INF},
        {INF, 4, 0, 5, INF, INF, 3, 2, INF, INF},
        {INF, INF, 5, 0, INF, INF, INF, 2, 1, INF},
        {1, INF, INF, INF, 0, 4, INF, INF, INF, 1},
        {INF, 6, INF, INF, 4, 0, 2, INF, INF, INF},
        {INF, INF, 3, INF, INF, 2, 0, 1, INF, INF},
        {INF, INF, 2, 2, INF, INF, 1, 0, 3, INF},
        {INF, INF, INF, 1, INF, INF, INF, 3, 0, 1},
        {INF, INF, INF, INF, 1, INF, INF, INF, 1, 0}
    };
        int V = adjMat.size();

        // Initialize distance matrix with the given graph
        vector<vector<int>> dist(V, vector<int>(V));
        for (int i = 0; i < V; ++i) {
            for (int j = 0; j < V; ++j) {
                if (adjMat[i][j]) {
                    dist[i][j] = weights[i][j];
                } else {
                    dist[i][j] = (i == j) ? 0 : INF;
                }
            }
        }

        // Update shortest distances by considering all vertices as intermediate vertices
        for (int k = 0; k < V; ++k) {
            for (int i = 0; i < V; ++i) {
                for (int j = 0; j < V; ++j) {
                    // If vertex k is on the shortest path from i to j, update the value of dist[i][j]
                    if (dist[i][k] != INF && dist[k][j] != INF && dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
        }

        // Print the shortest distances between every pair of vertices
        cout << "Shortest distances between every pair of vertices:\n";
        for (int i = 0; i < V; ++i) {
            for (int j = 0; j < V; ++j) {
                if (dist[i][j] == INF) {
                    cout << "INF\t";
                } else {
                    cout << dist[i][j] << "\t";
                }
            }
            cout << endl;
        }
    }


};

void createloan() {
    srand(time(0));
    int ch, n;
    long long account_number;  // Changed to long long to match the usual type for account numbers
    cout << "Enter Account Number: ";
    cin >> account_number;

    if (cin.fail()) {
        cout << "Invalid account number input." << endl;
        cin.clear(); // Clear the error flag
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
        return;
    }

    cout << "Select loan type: 1) Car 2) Home 3) Educational 4) Agricultural 5) Gold: ";
    cin >> ch;

    if (cin.fail() || ch < 1 || ch > 5) {
        cerr << "Invalid choice!" << endl;
        cin.clear(); // Clear the error flag
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
        return;
    }

    cout << "Enter number of years: ";
    cin >> n;

    if (cin.fail() || n <= 0) {
        cerr << "Invalid number of years!" << endl;
        cin.clear(); // Clear the error flag
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
        return;
    }

    IntGraph graph;
    switch (ch) {
        case 1: {
            CarLoan car_loan(account_number, n);
            car_loan.create_loan(account_number, n);
            graph.addEdge(car_loan.interest_rate);
            break;
        }
        case 2: {
            HomeLoan home_loan(account_number, n);
            home_loan.create_loan(account_number, n);
            graph.addEdge(home_loan.interest_rate);
            break;
        }
        case 3: {
            EducationalLoan educational_loan(account_number, n);
            educational_loan.create_loan(account_number, n);
            graph.addEdge(educational_loan.interest_rate);
            break;
        }
        case 4: {
            AgriculturalLoan agricultural_loan(account_number, n);
            agricultural_loan.create_loan(account_number, n);
            graph.addEdge(agricultural_loan.interest_rate);
            break;
        }
        case 5: {
            GoldLoan gold_loan(account_number, n);
            gold_loan.create_loan(account_number, n);
            graph.addEdge(gold_loan.interest_rate);
            break;
        }
        default:
            cout << "Invalid choice!" << endl;
            break;
    }

    cout << "Loan creation process completed." << endl;  // Added confirmation output
}


void admin(){
    int n;
    ownloan owner;
    IntGraph graph;
    x:{
        cout<<"1.Generate Loan List\n2.Topological sort\n3.Floyd Warshall\n4.Exit\nEnter your choice:";
        cin>>n;
        switch(n){
            case 1:
                owner.generateLoanPortfolioReport();
                cout<<"-------------------------------------\n";
                break;
            case 2:
                graph.topologicalSort();
                cout<<"-------------------------------------\n";
                break;
            case 3:
                graph.floydWarshall();
                cout<<"-------------------------------------\n";
                break;
            case 4:
                cout<<"-------------------------------------\n";
                return;
            default:
                cout<<"Entered Wrong Choice!\n";
                cout<<"-------------------------------------\n";
                goto x;
        }
    }
}


