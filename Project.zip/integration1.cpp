#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <tuple>
#include <climits>
#include <string>
#include <chrono>
#include <iomanip>
#include <queue>
#include <algorithm>
#include<bits/stdc++.h>
#include <cctype>
#include <random>
#include <unordered_set>
#include <ctime>
#include <vector>
#include <unordered_map>
#include "loanmanagement.h"
#include "administration.h"
#include "loanpayment.h"
using namespace std;

string trim(const string& str) {
    size_t first = str.find_first_not_of(' ');
    if (first == string::npos)
        return "";
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, last - first + 1);
}

class AuthenticationSystem {
private:
    string filename;
    bool authenticateCustomer(const string& accountNumber, const string& enteredMpin) {
        ifstream file(filename);
        string line;

        if (file.is_open()) {
            getline(file, line);

            while (getline(file, line)) {
                stringstream ss(line);
                string fileAccountNumber, userId, password, fileMpin;

                getline(ss, fileAccountNumber, ',');
                getline(ss, userId, ',');
                getline(ss, password, ',');
                getline(ss, fileMpin, ',');

                fileAccountNumber = trim(fileAccountNumber);
                fileMpin = trim(fileMpin);

                if (fileAccountNumber == accountNumber) {
                    return fileMpin == enteredMpin;
                }
            }
            file.close();
        } else {
            cerr << "Unable to open file" << endl;
        }

        return false;
    }

public:
    AuthenticationSystem(const string& filename) : filename(filename) {}
    bool authenticate(const string& accountNumber, const string& mpin) {

        if (authenticateCustomer(accountNumber, mpin)) {
            cout << "Authentication successful!" << endl;
            return true;
        } else {
            cout << "Authentication failed. Please check your account number and MPIN." << endl;
            return false;
        }
    }
};

struct SplayNode {
    string accountNumber;
    string userId;
    string password;
    SplayNode* left;
    SplayNode* right;
    SplayNode(const string& accNum, const string& uid, const string& pwd)
        : accountNumber(accNum), userId(uid), password(pwd), left(nullptr), right(nullptr) {}
};
const int MAX = 1e4 + 5;
class SplayTree {
public:
    SplayNode* root;

    SplayTree() : root(nullptr) {}

    SplayNode* rightRotate(SplayNode* x) {
        SplayNode* y = x->left;
        x->left = y->right;
        y->right = x;
        return y;
    }

    SplayNode* leftRotate(SplayNode* x) {
        SplayNode* y = x->right;
        x->right = y->left;
        y->left = x;
        return y;
    }

    SplayNode* splay(SplayNode* root, const string& key) {
        if (root == nullptr || root->accountNumber == key)
            return root;

        if (root->accountNumber > key) {
            if (root->left == nullptr) return root;

            if (root->left->accountNumber > key) {
                root->left->left = splay(root->left->left, key);
                root = rightRotate(root);
            }
            else if (root->left->accountNumber < key) {
                root->left->right = splay(root->left->right, key);
                if (root->left->right != nullptr)
                    root->left = leftRotate(root->left);
            }

            return (root->left == nullptr) ? root : rightRotate(root);
        } else {
            if (root->right == nullptr) return root;

            if (root->right->accountNumber > key) {
                root->right->left = splay(root->right->left, key);
                if (root->right->left != nullptr)
                    root->right = rightRotate(root->right);
            }
            else if (root->right->accountNumber < key) {
                root->right->right = splay(root->right->right, key);
                root = leftRotate(root);
            }

            return (root->right == nullptr) ? root : leftRotate(root);
        }
    }

    void insert(const string& accountNumber, const string& userId, const string& password) {
        if (root == nullptr) {
            root = new SplayNode(accountNumber, userId, password);
            return;
        }

        root = splay(root, accountNumber);

        if (root->accountNumber == accountNumber) return;

        SplayNode* newNode = new SplayNode(accountNumber, userId, password);

        if (root->accountNumber > accountNumber) {
            newNode->right = root;
            newNode->left = root->left;
            root->left = nullptr;
        } else {
            newNode->left = root;
            newNode->right = root->right;
            root->right = nullptr;
        }

        root = newNode;
    }

    SplayNode* search(const string& accountNumber) {
        root = splay(root, accountNumber);
        if (root != nullptr && root->accountNumber == accountNumber)
            return root;
        return nullptr;
    }
};

class Services {
private:
    SplayTree accountsTree;
    unordered_map<string, vector<pair<string, string>>> securityQuestionsMap;
    string accountsFilename;

    void loadAccountsFromCsv(const string& filename) {
        accountsFilename = filename;
        ifstream file(filename);
        string line, accountNumber, userId, password;

        if (file.is_open()) {
            getline(file, line);

            while (getline(file, line)) {
                stringstream ss(line);
                getline(ss, accountNumber, ',');
                getline(ss, userId, ',');
                getline(ss, password, ',');

                accountsTree.insert(accountNumber, userId, password);
            }
            file.close();
        } else {
            cerr << "Error: Unable to open file " << filename << " for reading." << endl;
        }
    }

    void loadSecurityQuestionsFromCsv(const string& filename) {
        ifstream file(filename);
        string line, userId, question, answer;

        if (file.is_open()) {
            getline(file, line);

            while (getline(file, line)) {
                stringstream ss(line);
                getline(ss, userId, ',');
                getline(ss, question, ',');
                getline(ss, answer, ',');

                securityQuestionsMap[userId].emplace_back(question, answer);
            }
            file.close();
        } else {
            cerr << "Error: Unable to open file " << filename << " for reading." << endl;
        }
    }

    bool promptSecurityQuestions(const string& userId) {
        if (securityQuestionsMap.find(userId) == securityQuestionsMap.end()) {
            cout << "No security questions found for the given User ID." << endl;
            return false;
        }

        const auto& questions = securityQuestionsMap[userId];
        for (const auto& pair : questions) {
            cout << "Question: " << pair.first << endl;
            bool correctAnswer = false;
            for (int attempt = 0; attempt < 3; ++attempt) {
                string userAnswer;
                cout << "Enter Your Answer: ";
                getline(cin, userAnswer);

                if (userAnswer == pair.second) {
                    cout << "Correct Answer!" << endl;
                    correctAnswer = true;
                    break;
                } else {
                    cout << "Incorrect Answer. ";
                    if (attempt < 2) {
                        cout << "Please try again." << endl;
                    } else {
                        cout << "You have failed to answer correctly 3 times." << endl;
                    }
                }
            }
            if (!correctAnswer) {
                return false;
            }
        }
        return true;
    }

    void updatePasswordInCsv(const string& accountNumber, const string& newPassword) {
        ifstream file(accountsFilename);
        stringstream buffer;
        buffer << file.rdbuf();
        file.close();

        ofstream tempFile("temp.csv");
        string line;
        while (getline(buffer, line)) {
            stringstream ss(line);
            string accountNum, userId, password;
            getline(ss, accountNum, ',');
            getline(ss, userId, ',');
            getline(ss, password, ',');

            if (accountNum == accountNumber) {
                tempFile << accountNum << "," << userId << "," << newPassword << "\n";
            } else {
                tempFile << line << "\n";
            }
        }
        tempFile.close();
        remove(accountsFilename.c_str());
        rename("temp.csv", accountsFilename.c_str());
    }

    void resetPassword(SplayNode* node) {
        string newPassword, confirmPassword;
        while (true) {
            cout << "Enter new password: ";
            cin >> newPassword;
            cout << "Confirm new password: ";
            cin >> confirmPassword;
            if (newPassword == confirmPassword) {
                node->password = newPassword;
                updatePasswordInCsv(node->accountNumber, newPassword);
                cout << "Password has been reset successfully!"<<endl;
                break;
            } else {
                cout << "Passwords do not match. Please try again." << endl;
            }
        }
    }

public:
    Services() {
        loadAccountsFromCsv("customers_data.csv");
        loadSecurityQuestionsFromCsv("security_questions.csv");
    }

    void login() {
        string accountNumber, password;
        SplayNode* node = nullptr;
        bool authenticated = false;
        int passwordAttempts = 0;

        while (!authenticated && passwordAttempts < 3) {
            cout << "Enter Account Number: ";
            cin >> accountNumber;
            cin.ignore();

            cout << "Enter Password: ";
            cin >> password;
            cin.ignore();

            node = accountsTree.search(accountNumber);
            if (node != nullptr) {
                if (node->password == password) {
                    cout << "Login successful!" << endl;
                    authenticated = true;
                } else {
                    passwordAttempts++;
                    if (passwordAttempts >= 3) {
                        cout << "Maximum password attempts reached. Exiting." << endl;
                        return;
                    }

                    cout << "Incorrect password." << endl;

                    char choice;
                    cout << "Forgot Password? (y/n): ";
                    cin >> choice;
                    cin.ignore();

                    if (choice == 'y' || choice == 'Y') {
                        if (promptSecurityQuestions(node->userId)) {
                            resetPassword(node);
                            authenticated = true;
                        } else {
                            cout << "Failed to verify security questions. Cannot reset password." << endl;
                            return;
                        }
                    } else if (choice == 'n' || choice == 'N') {
                        cout << "Please re-enter the password." << endl;
                    } else {
                        cout << "Invalid choice. Please enter 'y' or 'n'." << endl;
                    }
                }
            } else {
                cout << "Account number not found." << endl;
                return;
            }
        }
    }
};
class AdminSystem {
private:
    string adminId;
    string adminPassword;

public:
    AdminSystem(const string& adminId, const string& adminPassword)
        : adminId(adminId), adminPassword(adminPassword) {}

    bool authenticate(const string& enteredId, const string& enteredPassword) {
        return enteredId == adminId && enteredPassword == adminPassword;
    }

    void adminLogin() {
        string enteredId;
        string enteredPassword;

        cout << "Enter admin ID: ";
        cin >> enteredId;

        cout << "Enter admin password: ";
        cin >> enteredPassword;

        if (authenticate(enteredId, enteredPassword)) {
            cout << "Admin login successful!" << endl;
        } else {
            cout << "Admin login failed. Please check your ID and password." << endl;
        }
    }
};
class Customer {
public:
    string accountNumber;
    string userId;
    string password;
    string mpin;

    Customer(const string& accountNumber, const string& userId, const string& password, const string& mpin)
        : accountNumber(accountNumber), userId(userId), password(password), mpin(mpin) {}
};

class CustomerNode {
public:
    Customer customer;
    CustomerNode* left;
    CustomerNode* right;
    int height;

    CustomerNode(const Customer& customer)
        : customer(customer), left(nullptr), right(nullptr), height(1) {}
};
class CustomerAVLTree {
private:
    CustomerNode* root;

    int height(CustomerNode* node) {
        return node ? node->height : 0;
    }

    int balanceFactor(CustomerNode* node) {
        return node ? height(node->left) - height(node->right) : 0;
    }

    CustomerNode* rotateRight(CustomerNode* y) {
        CustomerNode* x = y->left;
        CustomerNode* T2 = x->right;
        x->right = y;
        y->left = T2;
        y->height = max(height(y->left), height(y->right)) + 1;
        x->height = max(height(x->left), height(x->right)) + 1;
        return x;
    }

    CustomerNode* rotateLeft(CustomerNode* x) {
        CustomerNode* y = x->right;
        CustomerNode* T2 = y->left;
        y->left = x;
        x->right = T2;
        x->height = max(height(x->left), height(x->right)) + 1;
        y->height = max(height(y->left), height(y->right)) + 1;
        return y;
    }

    CustomerNode* insert(CustomerNode* node, const Customer& customer) {
        if (!node) return new CustomerNode(customer);
        if (customer.accountNumber < node->customer.accountNumber)
            node->left = insert(node->left, customer);
        else if (customer.accountNumber > node->customer.accountNumber)
            node->right = insert(node->right, customer);
        else
            return node;

        node->height = 1 + max(height(node->left), height(node->right));
        int balance = balanceFactor(node);

        if (balance > 1 && customer.accountNumber < node->left->customer.accountNumber)
            return rotateRight(node);
        if (balance < -1 && customer.accountNumber > node->right->customer.accountNumber)
            return rotateLeft(node);
        if (balance > 1 && customer.accountNumber > node->left->customer.accountNumber) {
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }
        if (balance < -1 && customer.accountNumber < node->right->customer.accountNumber) {
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }

        return node;
    }

    CustomerNode* searchByAccountNumber(CustomerNode* node, const string& accountNumber) const {
        if (!node || node->customer.accountNumber == accountNumber)
            return node;
        if (accountNumber < node->customer.accountNumber)
            return searchByAccountNumber(node->left, accountNumber);
        return searchByAccountNumber(node->right, accountNumber);
    }

    bool searchByUserId(CustomerNode* node, const string& userId) const {
        if (!node) return false;
        if (node->customer.userId == userId) return true;
        return searchByUserId(node->left, userId) || searchByUserId(node->right, userId);
    }

    void inOrder(CustomerNode* node, ofstream& file) const {
        if (node) {
            inOrder(node->left, file);
            file << node->customer.accountNumber << ","
                 << node->customer.userId << ","
                 << node->customer.password << ","
                 << node->customer.mpin << endl;
            inOrder(node->right, file);
        }
    }

public:
    CustomerAVLTree() : root(nullptr) {}

    void insert(const Customer& customer) {
        root = insert(root, customer);
    }

    Customer* searchByAccountNumber(const string& accountNumber) const {
        CustomerNode* result = searchByAccountNumber(root, accountNumber);
        return result ? &result->customer : nullptr;
    }

    bool searchByUserId(const string& userId) const {
        return searchByUserId(root, userId);
    }

    void inOrderTraversal(const string& filename) const {
        ofstream file(filename);
        if (file.is_open()) {
            file << "Account Number,User ID,Password,MPIN" << endl;
            inOrder(root, file);
            file.close();
        } else {
            cerr << "Error: Unable to open file " << filename << " for writing." << endl;
        }
    }
};
class ServiceSystem {
private:
    CustomerAVLTree customerTree;
    void loadCustomersFromCsv(const string& filename) {
        ifstream file(filename);
        string line, accountNumber, userId, password, mpin;
        if (file.is_open()) {
            getline(file, line);
            while (getline(file, line)) {
                stringstream ss(line);
                getline(ss, accountNumber, ',');
                getline(ss, userId, ',');
                getline(ss, password, ',');
                getline(ss, mpin, ',');

                Customer customer(accountNumber, userId, password, mpin);
                customerTree.insert(customer);
            }
            file.close();
        } else {
            cerr << "Error: Unable to open file " << filename << " for reading." << endl;
        }
    }

    bool accountNumberExists(const string& accountNumber) const {
        return customerTree.searchByAccountNumber(accountNumber) != nullptr;
    }

    bool userIdExists(const string& userId) const {
        return customerTree.searchByUserId(userId);
    }

public:
    ServiceSystem() {
        loadCustomersFromCsv("customers_data.csv");
    }

    void addOrUpdateCustomer(const Customer& customer) {
        customerTree.insert(customer);
    }

    void promptAndStoreData() {
        string accountNumber, userId, password, confirmPassword, mpin, confirmMpin;
        cout<<"------------Let us set a Password and MPIN------------\n";
        do {
            cout << "Enter Account Number: ";
            cin >> accountNumber;
            cin.ignore();

            if (accountNumberExists(accountNumber)) {
                cout << "Account Number already registered. Please enter a different Account Number." << endl;
            }
        } while (accountNumberExists(accountNumber));

        do {
            cout << "Enter User ID: ";
            cin >> userId;

            if (userIdExists(userId)) {
                cout << "User ID already exists. Please enter a different User ID." << endl;
            }
        } while (userIdExists(userId));

        do {
            cout << "Enter Password: ";
            cin >> password;
            cout << "Confirm Password: ";
            cin >> confirmPassword;

            if (password != confirmPassword) {
                cout << "Passwords do not match. Please try again." << endl;
            }
        } while (password != confirmPassword);

        do {
            cout << "Enter MPIN (6 digits): ";
            cin >> mpin;
            cout << "Confirm MPIN: ";
            cin >> confirmMpin;

            if (mpin != confirmMpin || mpin.length() != 6 || !all_of(mpin.begin(), mpin.end(), ::isdigit)) {
                cout << "MPIN does not match or is not valid. Please enter a 6-digit numeric MPIN." << endl;
            }
        } while (mpin != confirmMpin || mpin.length() != 6 || !all_of(mpin.begin(), mpin.end(), ::isdigit));

        Customer customer(accountNumber, userId, password, mpin);
        addOrUpdateCustomer(customer);
        writeDataToCsv();
        cout<<"Your Password and MPIN has been set successfully!\n";
    }

    void writeDataToCsv() {
        string filename = "customers_data.csv";
        customerTree.inOrderTraversal(filename);
    }
};

struct UpdateRequest {
    long long accountNumber; // Changed to long long
    double amount;
    string transaction;
    time_t timestamp; // Added timestamp field
};

// Function to write transaction details to CSV file with timestamp
void writeTransaction(const string& filename, const UpdateRequest& request) {
    ofstream file(filename, ios_base::app);
    if (!file.is_open()) {
        cerr << "Error: Unable to open transaction file." << endl;
        return;
    }

    // Write transaction details with timestamp
    file << request.accountNumber << "," << request.amount << "," << request.transaction << "," << ctime(&request.timestamp);
    file.close();
}

// Function to perform transaction and update balance in accountDetails.csv
void performTransaction(const string& accountDetailsFile, long long accountNumber, double amount, const string& transactionType) {
    ifstream file(accountDetailsFile);
    if (!file.is_open()) {
        cerr << "Error: Unable to open account details file." << endl;
        return;
    }

    ofstream tempFile("temp.csv");
    if (!tempFile.is_open()) {
        cerr << "Error: Unable to create temporary file." << endl;
        return;
    }

    string line;
    bool accountFound = false;
    bool skipHeader = true; // Flag to skip the header line

    while (getline(file, line)) {
        if (skipHeader) {
            skipHeader = false;
            tempFile << line << endl; // Write header line to temporary file
            continue; // Skip header line
        }

        stringstream ss(line);
        string token;
        getline(ss, token, ',');
        try {
            long long currentAccountNumber = stoll(token); // Convert string to long long
            if (currentAccountNumber == accountNumber) {
                accountFound = true;
                double balance;
                string accountHolder, address, phoneNumber, mailID, PANNumber, accountType, status,cibilScore;
                getline(ss, accountHolder, ',');
                getline(ss, address, ',');
                getline(ss, phoneNumber, ',');
                getline(ss, mailID, ',');
                getline(ss, PANNumber, ',');
                getline(ss, accountType, ',');
                ss >> balance; // Read current balance
                ss.ignore(); // Ignore comma
                getline(ss, status, ',');
                getline(ss, cibilScore, ' ');

                // Update balance based on transaction type
                if (transactionType == "deposit") {
                    balance += amount;
                } else if (transactionType == "withdraw") {
                    if (balance < amount) {
                        cerr << "Error: Insufficient balance." << endl;
                        return;
                    }
                    balance -= amount;
                }

                // Write all values to temporary file
                tempFile << accountNumber << "," << accountHolder << "," << address << "," << phoneNumber << "," << mailID << "," << PANNumber << "," << accountType << "," << balance << "," << status << "," << cibilScore << endl;
            } else {
                tempFile << line << endl; // Write unchanged line to temporary file
            }
        } catch (const invalid_argument& e) {
            cerr << "Error: Invalid account number encountered while parsing the file." << endl;
            cerr << "Line content: " << line << endl;
            return;
        } catch (const out_of_range& e) {
            cerr << "Error: Account number out of range encountered while parsing the file." << endl;
            cerr << "Line content: " << line << endl;
            return;
        }
    }

    file.close();
    tempFile.close();

    // Rename temporary file to accountDetails.csv
    if (remove(accountDetailsFile.c_str()) != 0) {
        cerr << "Error: Unable to remove original file." << endl;
        return;
    }
    if (rename("temp.csv", accountDetailsFile.c_str()) != 0) {
        cerr << "Error: Unable to rename temporary file." << endl;
        return;
    }
}
class Card {
protected:
    string accountNumber;
    string cardNumber;
    string expirationDate;
    string cvv;
    string status;
    string pin;
    string issueDate;
    string cardType;
    string cardHolderName;

public:
    Card() {}
    Card(string accNum, string cNum, string expDate, string cvv,
         string status, string pin, string issueDate, string cType, string holderName)
        : accountNumber(accNum), cardNumber(cNum), expirationDate(expDate), cvv(cvv),
          status(status), pin(pin), issueDate(issueDate), cardType(cType), cardHolderName(holderName) {}

    virtual ~Card() {} // Virtual destructor

    virtual void displayCardDetails() const {
        cout << "Account Number: " << accountNumber << "\nCard Number: " << cardNumber
             << "\nExpiration Date: " << expirationDate << "\nCVV: " << cvv
             << "\nStatus: " << status << "\nPIN: " << pin << "\nIssue Date: " << issueDate
             << "\nCard Type: " << cardType << "\nCard Holder Name: " << cardHolderName << endl;
    }

    virtual Card* clone() const = 0;

    string toCSV() const {
        return accountNumber + "," + cardNumber + "," + expirationDate + "," + cvv + "," +
               status + "," + pin + "," + issueDate + "," + cardType + "," + cardHolderName;
    }

    // Getters for various attributes
    string getAccountNumber() const {
        return accountNumber;
    }

    string getCardNumber() const {
        return cardNumber;
    }

    string getExpirationDate() const {
        return expirationDate;
    }

    string getCVV() const {
        return cvv;
    }

    string getStatus() const {
        return status;
    }

    string getPIN() const {
        return pin;
    }

    string getIssueDate() const {
        return issueDate;
    }

    string getCardType() const {
        return cardType;
    }

    string getCardHolderName() const {
        return cardHolderName;
    }
    void setStatus(const string& newStatus) {
        status = newStatus;
    }
};

class DebitCard : public Card {
public:
    DebitCard(string accNum, string cNum, string expDate, string cvv,
              string status, string pin, string issueDate, string cType, string holderName)
        : Card(accNum, cNum, expDate, cvv, status, pin, issueDate, cType, holderName) {}

    void displayCardDetails() const override {
        cout << "Debit Card Details:\n";
        Card::displayCardDetails();
    }

    Card* clone() const override {
        return new DebitCard(*this);
    }
};

class Creditcard : public Card {
public:
    Creditcard(string accNum, string cNum, string expDate, string cvv,
               string status, string pin, string issueDate, string cType, string holderName)
        : Card(accNum, cNum, expDate, cvv, status, pin, issueDate, cType, holderName) {}

    void displayCardDetails() const override {
        cout << "Credit Card Details:\n";
        Card::displayCardDetails();
    }

    Card* clone() const override {
        return new Creditcard(*this);
    }
};

class CardManagement {
private:
    unordered_map<string, Card*> debitCards;
    unordered_map<string, Card*> creditCards;
    string debitCardFile;
    string creditCardFile;

    void saveCards(const unordered_map<string, Card*>& cardMap, const string& filename) {
    // Open the file in append mode to add new records at the end
    ofstream file(filename, ios::app);
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    // Check if the file is empty
    ifstream checkFile(filename);
    bool fileIsEmpty = (checkFile.peek() == ifstream::traits_type::eof());
    checkFile.close();

    // If the file is empty, write attribute names to the file
    if (fileIsEmpty) {
        file << "AccountNumber,CardNumber,ExpirationDate,CVV,Status,PIN,IssueDate,CardType,CardHolderName" << endl;
    }

    // Read existing records from the file
    unordered_set<string> existingRecords;
    ifstream existingFile(filename);
    if (!existingFile.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        file.close();
        return;
    }
    string line;
    while (getline(existingFile, line)) {
        existingRecords.insert(line);
    }
    existingFile.close();

    // Write each new card entry to the file if it doesn't already exist
    for (const auto& pair : cardMap) {
        const Card* card = pair.second;
        string cardCSV = card->toCSV();
        if (existingRecords.find(cardCSV) == existingRecords.end()) {
            file << cardCSV << endl;
        }
    }

    file.close();
}



    void loadCards(const string& filename, unordered_map<string, Card*>& cardMap, bool isDebit) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "Error opening file: " << filename << endl;
            return;
        }
        string line;
        getline(file, line); // Skip the first line (attribute names)
        while (getline(file, line)) {
            stringstream ss(line);
            string accNum, cNum, expDate, cvv, status, pin, issueDate, cType, holderName;
            getline(ss, accNum, ',');
            getline(ss, cNum, ',');
            getline(ss, expDate, ',');
            getline(ss, cvv, ',');
            getline(ss, status, ',');
            getline(ss, pin, ',');
            getline(ss, issueDate, ',');
            getline(ss, cType, ',');
            getline(ss, holderName, ',');
            Card* card = isDebit
                ? (Card*)new DebitCard(accNum, cNum, expDate, cvv, status, pin, issueDate, cType, holderName)
                : (Card*)new Creditcard(accNum, cNum, expDate, cvv, status, pin, issueDate, cType, holderName);
            cardMap[cNum] = card;
        }
        file.close();
    }

    string generateRandomNumber(int length) {
        static random_device rd;
        static mt19937 gen(rd());
        uniform_int_distribution<> dis(0, 9);
        string number;
        for (int i = 0; i < length; ++i) {
            number += to_string(dis(gen));
        }
        return number;
    }

public:
    CardManagement(const string& debitFile, const string& creditFile)
        : debitCardFile(debitFile), creditCardFile(creditFile) {
        loadCards(debitCardFile, debitCards, true);
        loadCards(creditCardFile, creditCards, false);
    }

    ~CardManagement() {
        for (auto& pair : debitCards) delete pair.second;
        for (auto& pair : creditCards) delete pair.second;
    }

    void issueCard(bool isDebit, const Card& card) {
        unordered_map<string, Card*>& cardMap = isDebit ? debitCards : creditCards;
        cardMap[card.getCardNumber()] = card.clone();
        saveCards(cardMap, isDebit ? debitCardFile : creditCardFile);
    }

        void displayAllCards(bool isDebit) const {
        const unordered_map<string, Card*>& cardMap = isDebit ? debitCards : creditCards;
        for (const auto& pair : cardMap) {
            pair.second->displayCardDetails();
            cout << endl;
        }
    }
    void deactivateCard() {
    char cardTypeChoice;
    cout << "Deactivate which type of card? (d for Debit, c for Credit): ";
    cin >> cardTypeChoice;

    bool isDebit = (cardTypeChoice == 'd');

    string cardNumber;
    cout << "Enter the card number to deactivate: ";
    cin >> cardNumber;

    cout << "Reason for deactivation:\n";
    cout << "1. User's request\n";
    cout << "2. Card expired\n";
    int reasonChoice;
    cin >> reasonChoice;
    string reason = (reasonChoice == 1) ? "user's request" : "card expired";

    string filename = isDebit ? debitCardFile : creditCardFile;
    fstream file(filename, ios::in | ios::out);

    if (!file.is_open()) {
        cerr << "Error opening file.\n";
        return;
    }

    string line;
    stringstream buffer;
    bool cardFound = false;

    while (getline(file, line)) {
        stringstream ss(line);
        string accNum, cNum, expDate, cvv, status, pin, issueDate, cType, holderName;
        getline(ss, accNum, ',');
        getline(ss, cNum, ',');
        getline(ss, expDate, ',');
        getline(ss, cvv, ',');
        getline(ss, status, ',');
        getline(ss, pin, ',');
        getline(ss, issueDate, ',');
        getline(ss, cType, ',');
        getline(ss, holderName, ',');

        if (cNum == cardNumber) {
            cardFound = true;
            // Change status to deactivated
            status = "deactive";
        }
        // Write the (possibly modified) line to the buffer
        buffer << accNum << ',' << cNum << ',' << expDate << ',' << cvv << ','
               << status << ',' << pin << ',' << issueDate << ',' << cType
               << ',' << holderName << '\n';
    }

    file.close();

    if (cardFound) {
        // Write the updated content back to the file
        ofstream outFile(filename);
        if (!outFile.is_open()) {
            cerr << "Error opening file for writing.\n";
            return;
        }
        outFile << buffer.str();
        outFile.close();
        cout << "Card " << cardNumber << " has been deactivated due to " << reason << ".\n";
    } else {
        cout << "Card " << cardNumber << " not found.\n";
    }
}




    void interactiveIssueCard() {
        string accountNumber = generateRandomNumber(10);
        string cardNumber = generateRandomNumber(16);
        string pin = generateRandomNumber(4);
        string expirationDate, cvv, status = "active", issueDate, cardType, cardHolderName; // Default status is active

        cout << "Generated Account Number: " << accountNumber << endl;
        cout << "Generated Card Number: " << cardNumber << endl;
        cout << "Generated PIN: " << pin << endl;
        cout << "Enter expiration date (MM-YYYY): ";
        cin >> expirationDate;
        cout << "Enter CVV: ";
        cin >> cvv;
        cout << "Enter issue date (YYYY-MM-DD): ";
        cin >> issueDate;
        cout << "Enter card holder name: ";
        cin.ignore(); // To clear the newline character left by std::cin
        getline(cin, cardHolderName);
        cout << "Is this a debit card or credit card? (d/c): ";
        char cardTypeChoice;
        cin >> cardTypeChoice;

        bool isDebit = (cardTypeChoice == 'd'); // Move this line here

        if (isDebit) {
            cout << "Select Debit Card Type:\n";
            cout << "1. Maestro Debit Card\n";
            cout << "2. Visa Electro Debit Card\n";
            cout << "3. RuPay Debit Card\n";
            cout << "4. Contactless Debit Card\n";
            cout << "5. MasterCard Debit Card\n";
            cout << "6. Visa Debit Card\n";
            int choice;
            cin >> choice;
            switch (choice) {
                case 1: cardType = "Maestro Debit Card"; break;
                case 2: cardType = "Visa Electro Debit Card"; break;
                case 3: cardType = "RuPay Debit Card"; break;
                case 4: cardType = "Contactless Debit Card"; break;
                case 5: cardType = "MasterCard Debit Card"; break;
                case 6: cardType = "Visa Debit Card"; break;
                default: cout << "Invalid choice! Defaulting to 'Visa Debit Card'.\n"; cardType = "Visa Debit Card"; break;
            }
            DebitCard newDebitCard(accountNumber, cardNumber, expirationDate, cvv, status, pin, issueDate, cardType, cardHolderName);
            issueCard(true, newDebitCard);
        } else {
            cout << "Select Credit Card Type:\n";
            cout << "1. Regular Credit Card\n";
            cout << "2. Premium Credit Card\n";
            cout << "3. Commercial or Business Credit Card\n";
            cout << "4. CashBack Credit Card\n";
            cout << "5. Travel Credit Card\n";
            cout << "6. Shopping Credit Card\n";
            cout << "7. Fuel Credit Card\n";
            int choice;
            cin >> choice;
            switch (choice) {
                case 1: cardType = "Regular Credit Card"; break;
                case 2: cardType = "Premium Credit Card"; break;
                case 3: cardType = "Commercial or Business Credit Card"; break;
                case 4: cardType = "CashBack Credit Card"; break;
                case 5: cardType = "Travel Credit Card"; break;
                case 6: cardType = "Shopping Credit Card"; break;
                case 7: cardType = "Fuel Credit Card"; break;
                default: cout << "Invalid choice! Defaulting to 'Regular Credit Card'.\n"; cardType = "Regular Credit Card"; break;
            }
            Creditcard newCreditCard(accountNumber, cardNumber, expirationDate, cvv, status, pin, issueDate, cardType, cardHolderName);
            issueCard(false, newCreditCard);
        }

        cout << "Card issued successfully!\n";
    }

    void runCardManagementSystem() {
        char choice;
        do {
            cout << "\nAdmin Menu:\n";
            cout << "1. Issue a new card\n";
            cout << "2. Display all debit cards\n";
            cout << "3. Display all credit cards\n";
            cout << "4. Deactivate a card\n"; // New option
            cout << "5. Exit\n";
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
            case '1':
                interactiveIssueCard();
                break;
            case '2':
                cout << "All Debit Cards:\n";
                displayAllCards(true);
                break;
            case '3':
                cout << "All Credit Cards:\n";
                displayAllCards(false);
                break;
            case '4':
                    cout << "Deactivate a card:\n";
                    deactivateCard(); // Assuming deactivating a debit card, change to false for credit card
                    break;
                case '5':
                    cout << "Exiting...\n";
                    break;
            default:
                cout << "Invalid choice! Please try again.\n";
            }
        } while (choice!='5');
    }
};
class CustomerSupport {
public:
    virtual void addQuestion(const string& question, const string& answer) = 0;
    virtual string getAnswer(const string& question) = 0;
    virtual void displayQuestions() = 0;
    virtual void logCustomerQuery(const string& question) = 0;
    virtual void displayCustomerQueries() = 0;
    virtual void performBFS() = 0;
    virtual void performDFS() = 0;
    virtual double checkAccountBalance(const string& accountNumber) = 0;
};
class BankNetwork {
private:
    const int MAX = 1e4 + 5;
    vector<vector<pair<int, int>>> adj;
    int nodes, edges;

public:
    BankNetwork(int n, int e) : nodes(n), edges(e) {
        adj.resize(MAX);
    }

    void addEdge(int u, int v, int w) {
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});
    }

    void dijkstra(int src) {
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        vector<int> dist(nodes + 1, INT_MAX);
        dist[src] = 0;
        pq.push({0, src});

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();
            for (auto& edge : adj[u]) {
                int v = edge.first;
                int weight = edge.second;
                if (dist[v] > dist[u] + weight) {
                    dist[v] = dist[u] + weight;
                    pq.push({dist[v], v});
                }
            }
        }

        cout << "Shortest distances from Bank " << src << ":\n";
        for (int i = 1; i <= nodes; ++i) {
            cout << "To Account Holder " << i << ": " << dist[i] << " km\n";
        }
    }

    void run() {
        cout << "Enter the edges (Ac_Num1 Ac_Num2 distance):\n";
        for (int i = 0; i < edges; ++i) {
            int x, y, weight;
            cin >> x >> y >> weight;
            addEdge(x, y, weight);
        }

        int source;
        cout << "Enter the Bank node: ";
        cin >> source;
        dijkstra(source);
    }
};
void runBankNetwork() {
    int nodes, edges;
    cout << "Enter total number of Account Holders and Paths: ";
    cin >> nodes >> edges;

    BankNetwork network(nodes, edges);
    network.run();
}
class ChatbotSupport : public CustomerSupport {
private:
    map<string, string> questionAnswerMap;
    vector<pair<string, string>> customerQueries;
    vector<vector<int>> adjacencyList; // for graph representation
    map<string, double> accountBalances; // for dynamic account balance

    string getCurrentTime() {
        auto now = chrono::system_clock::to_time_t(chrono::system_clock::now());
        char buf[20]; // Buffer to store formatted time
        strftime(buf, sizeof(buf), "%Y-%m-%d %X", localtime(&now));
        return string(buf);
    }

    void buildGraph() {
        // Assuming the questions are numbered from 1 to n
        int numQuestions = questionAnswerMap.size();
        adjacencyList.resize(numQuestions + 1); // +1 for 1-based indexing

        // Add edges based on relationships between questions
        // For simplicity, assume edges based on consecutive questions
        int index = 1;
        for (auto it = questionAnswerMap.begin(); it != questionAnswerMap.end(); ++it, ++index) {
            if (index < numQuestions) {
                adjacencyList[index].push_back(index + 1); // Connect question i with question i+1
            }
        }
    }

public:
    ChatbotSupport() {
        // Predefined questions and answers
        addQuestion("How do I open a bank account?", "To open a bank account, visit our nearest branch with valid ID proof and address proof.");
        addQuestion("What are the types of accounts offered?", "We offer savings accounts, current accounts, and fixed deposit accounts.");
        addQuestion("How can I apply for a credit card?", "You can apply for a credit card online through our website or visit a branch for assistance.");

        // Additional questions and answers
        addQuestion("What is the interest rate on savings accounts?", "The interest rate on savings accounts is 1.5% per annum.");
        addQuestion("Can I transfer money internationally from my account?", "Yes, you can transfer money internationally through our online banking portal.");
        addQuestion("How do I set up online banking?", "You can set up online banking by visiting our website and following the instructions for registration.");
        addQuestion("What is the process for applying for a mortgage?", "To apply for a mortgage, you need to submit your application along with necessary documents to our mortgage department.");
        addQuestion("How can I increase my credit limit on a credit card?", "You can request to increase your credit limit by contacting our customer service or visiting a branch.");
        addQuestion("What should I do if my card is lost or stolen?", "If your card is lost or stolen, immediately contact our customer service to report it and request a replacement.");

        // New questions
        addQuestion("How do I check my account balance?", "You can check your account balance through our mobile app, ATM, or by visiting a branch.");
        addQuestion("What is the minimum balance required in a savings account?", "The minimum balance required in a savings account is $1000.");
        addQuestion("What is the available balance in my savings account?", "Your available balance in the savings account is $");

        // Build the graph representation
        buildGraph();
    }

    void addQuestion(const string& question, const string& answer) override {
        questionAnswerMap[question] = answer;
    }

    string getAnswer(const string& question) override {
        logCustomerQuery(question);
        if (question == "What is the available balance in my savings account?") {
            // Handle the dynamic response for account balance
            return "Please enter your account number to check the balance.";
        }
        if (questionAnswerMap.find(question) != questionAnswerMap.end()) {
            return questionAnswerMap[question];
        } else {
            return "Sorry, I don't have an answer for that question.";
        }
    }

    void displayQuestions() override {
        cout << "Available Questions:\n";
        for (const auto& qa : questionAnswerMap) {
            cout << qa.first << endl;
        }
    }

    void logCustomerQuery(const string& question) override {
        customerQueries.push_back({getCurrentTime(), question});
    }

    void displayCustomerQueries() override {
        cout << "Customer Queries Log:\n";
        for (const auto& query : customerQueries) {
            cout << "[" << query.first << "] " << query.second << endl;
        }
    }

    void performBFS() override {
        queue<int> q;
        vector<bool> visited(adjacencyList.size(), false);

        q.push(1); // Start BFS from question 1
        visited[1] = true;

        while (!q.empty()) {
            int node = q.front();
            q.pop();
            cout << "Question " << node << ": " << questionAnswerMap["Question " + to_string(node)] << endl;

            for (int neighbor : adjacencyList[node]) {
                if (!visited[neighbor]) {
                    q.push(neighbor);
                    visited[neighbor] = true;
                }
            }
        }
    }

    void performDFS() override {
        stack<int> st;
        vector<bool> visited(adjacencyList.size(), false);

        st.push(1); // Start DFS from question 1

        while (!st.empty()) {
            int node = st.top();
            st.pop();

            if (!visited[node]) {
                cout << "Question " << node << ": " << questionAnswerMap["Question " + to_string(node)] << endl;
                visited[node] = true;

                for (int neighbor : adjacencyList[node]) {
                    if (!visited[neighbor]) {
                        st.push(neighbor);
                    }
                }
            }
        }
    }

    double checkAccountBalance(const string& accountNumber) override {
        // Dummy implementation, replace with actual account balance retrieval logic
        if (accountBalances.find(accountNumber) != accountBalances.end()) {
            return accountBalances[accountNumber];
        } else {
            return -1.0; // Account number not found
        }
    }

    void setAccountBalance(const string& accountNumber, double balance) {
        accountBalances[accountNumber] = balance;
    }
};

void runSupportSystem() {
    ChatbotSupport supportSystem;
    int choice;
    string question, answer, accountNumber;

    supportSystem.setAccountBalance("Savings123", 5000.0); // Set initial balance

    do {
        cout << "1. Ask Question\n2. Display Questions\n3. Display Customer Queries\n4. Check Account Balance\n5. Exit\nEnter your choice: ";
        cin >> choice;
        cin.ignore(); // to ignore the newline character after choice input

        switch (choice) {
            case 1:
                cout << "Enter your question: ";
                getline(cin, question);
                answer = supportSystem.getAnswer(question);
                if (question == "What is the available balance in my savings account?") {
                    cout << "Enter your account number: ";
                    cin >> accountNumber;
                    answer += to_string(supportSystem.checkAccountBalance(accountNumber));
                    cin.ignore();
                }
                cout << "Answer: " << answer << endl;
                break;
            case 2:
                supportSystem.displayQuestions();
                break;
            case 3:
                supportSystem.displayCustomerQueries();
                break;
            case 4:
                cout << "Enter account number: ";
                cin >> accountNumber;
                cout << "Account Balance: $" << supportSystem.checkAccountBalance(accountNumber) << endl;
                break;
            case 5:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice! Please enter a valid option." << endl;
                break;
        }
    } while (choice != 5);
}
class HeapNode {
public:
    string account_number;
    int cibil_score;

    HeapNode(string accNumber, int score) : account_number(accNumber), cibil_score(score) {}
};

// Max Heap
class MaxHeap {
private:
    vector<HeapNode> heap;

    int parent(int i) { return (i - 1) / 2; } // Parent index of node at index i
    int left(int i) { return (2 * i + 1); }   // Left child index of node at index i
    int right(int i) { return (2 * i + 2); }  // Right child index of node at index i

    // Heapify the subtree rooted at index i
    void heapify(int i) {
        int largest = i;
        int l = left(i);
        int r = right(i);

        // Check if left child exists and is greater than the current node
        if (l < heap.size() && heap[l].cibil_score > heap[largest].cibil_score) {
            largest = l;
        }

        // Check if right child exists and is greater than the current node
        if (r < heap.size() && heap[r].cibil_score > heap[largest].cibil_score) {
            largest = r;
        }

        // If largest is not the current node, swap the current node with the largest and heapify the affected subtree
        if (largest != i) {
            swap(heap[i], heap[largest]);
            heapify(largest);
        }
    }

public:
    void insert(HeapNode node) {
        heap.push_back(node);
        int i = heap.size() - 1;
        while (i > 0 && heap[parent(i)].cibil_score < heap[i].cibil_score) {
            swap(heap[i], heap[parent(i)]);
            i = parent(i);
        }
    }

    void display() {
        cout << "Max Heap (Account Number, CIBIL Score):" << endl;
        for (auto node : heap) {
            cout << "(" << node.account_number << ", " << node.cibil_score << ")" << endl;
        }
    }
    const vector<HeapNode>& getHeap() const {
        return heap;
    }
};
class Solution {
private:
	void findTopoSort(int node, vector<int>& visited, stack<int>& st, vector<int> adj[]) {
    	visited[node] = 1;
    	for (auto it : adj[node]) {
        	if (!visited[it]) {
            	findTopoSort(it, visited, st, adj);
        	}
    	}
    	st.push(node);
	}

public:
	vector<int> topoSort(int N, vector<int> adj[]) {
    	stack<int> st;
    	vector<int> visited(N, 0);
    	for (int i = 0; i < N; i++) {
        	if (!visited[i]) {
            	findTopoSort(i, visited, st, adj);
        	}
    	}
    	vector<int> topo;
    	while (!st.empty()) {
        	topo.push_back(st.top());
        	st.pop();
    	}
    	return topo;
	}
};
class splaynode {
public:
    string cardNumber;
    string cardDetails; // A string containing other details of the card
    splaynode* left;
    splaynode* right;

    splaynode(string cardNumber, string cardDetails)
        : cardNumber(cardNumber), cardDetails(cardDetails), left(nullptr), right(nullptr) {}
};

class splaytree {
private:
    splaynode* root;

    splaynode* rightRotate(splaynode* x) {
        splaynode* y = x->left;
        x->left = y->right;
        y->right = x;
        return y;
    }

    splaynode* leftRotate(splaynode* x) {
        splaynode* y = x->right;
        x->right = y->left;
        y->left = x;
        return y;
    }

    splaynode* splay(splaynode* root, const string& cardNumber) {
        if (!root || root->cardNumber == cardNumber)
            return root;

        if (root->cardNumber > cardNumber) {
            if (!root->left) return root;
            if (root->left->cardNumber > cardNumber) {
                root->left->left = splay(root->left->left, cardNumber);
                root = rightRotate(root);
            } else if (root->left->cardNumber < cardNumber) {
                root->left->right = splay(root->left->right, cardNumber);
                if (root->left->right)
                    root->left = leftRotate(root->left);
            }
            return root->left ? rightRotate(root) : root;
        } else {
            if (!root->right) return root;
            if (root->right->cardNumber > cardNumber) {
                root->right->left = splay(root->right->left, cardNumber);
                if (root->right->left)
                    root->right = rightRotate(root->right);
            } else if (root->right->cardNumber < cardNumber) {
                root->right->right = splay(root->right->right, cardNumber);
                root = leftRotate(root);
            }
            return root->right ? leftRotate(root) : root;
        }
    }

public:
    splaytree() : root(nullptr) {}

    void insert(const string& cardNumber, const string& cardDetails) {
        if (!root) {
            root = new splaynode(cardNumber, cardDetails);
            return;
        }
        root = splay(root, cardNumber);
        if (root->cardNumber == cardNumber) return;

        splaynode* newNode = new splaynode(cardNumber, cardDetails);
        if (root->cardNumber > cardNumber) {
            newNode->right = root;
            newNode->left = root->left;
            root->left = nullptr;
        } else {
            newNode->left = root;
            newNode->right = root->right;
            root->right = nullptr;
        }
        root = newNode;
    }

    splaynode* search(const string& cardNumber) {
        root = splay(root, cardNumber);
        return (root && root->cardNumber == cardNumber) ? root : nullptr;
    }
};

class avlNode {
public:
    string cardNumber;
    string pin;
    int height;
    avlNode* left;
    avlNode* right;

    avlNode(string cardNumber, string pin)
        : cardNumber(cardNumber), pin(pin), height(1), left(nullptr), right(nullptr) {}
};

class avlTree {
private:
    avlNode* root;

    int height(avlNode* node) {
        return node ? node->height : 0;
    }

    int balanceFactor(avlNode* node) {
        return node ? height(node->left) - height(node->right) : 0;
    }

    avlNode* rotateRight(avlNode* y) {
        avlNode* x = y->left;
        avlNode* T2 = x->right;

        x->right = y;
        y->left = T2;

        y->height = max(height(y->left), height(y->right)) + 1;
        x->height = max(height(x->left), height(x->right)) + 1;

        return x;
    }

    avlNode* rotateLeft(avlNode* x) {
        avlNode* y = x->right;
        avlNode* T2 = y->left;

        y->left = x;
        x->right = T2;

        x->height = max(height(x->left), height(x->right)) + 1;
        y->height = max(height(y->left), height(y->right)) + 1;

        return y;
    }

    avlNode* search(avlNode* node, const string& cardNumber) {
        if (!node || node->cardNumber == cardNumber)
            return node;
        if (node->cardNumber < cardNumber)
            return search(node->right, cardNumber);
        return search(node->left, cardNumber);
    }

public:
    avlTree() : root(nullptr) {}

    void updatePin(const string& cardNumber, const string& newPin) {
        avlNode* node = search(root, cardNumber);
        if (node) {
            node->pin = newPin;
        }
    }

    void insert(const string& cardNumber, const string& pin) {
        root = insert(root, cardNumber, pin);
    }

    avlNode* insert(avlNode* node, const string& cardNumber, const string& pin) {
        if (!node)
            return new avlNode(cardNumber, pin);

        if (cardNumber < node->cardNumber)
            node->left = insert(node->left, cardNumber, pin);
        else if (cardNumber > node->cardNumber)
            node->right = insert(node->right, cardNumber, pin);

        node->height = 1 + max(height(node->left), height(node->right));

        int balance = balanceFactor(node);

        if (balance > 1 && cardNumber < node->left->cardNumber)
            return rotateRight(node);

        if (balance < -1 && cardNumber > node->right->cardNumber)
            return rotateLeft(node);

        if (balance > 1 && cardNumber > node->left->cardNumber) {
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }

        if (balance < -1 && cardNumber < node->right->cardNumber) {
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }

        return node;
    }

    string search(const string& cardNumber) {
        avlNode* node = search(root, cardNumber);
        return node ? node->pin : "Card not found";
    }
};

class CardGraph {
private:
    unordered_map<string, vector<string>> adjList;
    unordered_map<string, bool> blockedStatus;

public:
    void addEdge(const string& cardNumber, bool blocked) {
    if (blocked) {
        // If the card is blocked, we don't add any edges.
        return;
    }

    // Otherwise, add an edge between the current card and its adjacent cards.
    // In this example, we'll assume that adjacent cards are all other cards in the system.
    for (const auto& entry : blockedStatus) {
        const string& otherCard = entry.first;
        if (otherCard != cardNumber && !entry.second) {
            // If the other card is not the current card and is not blocked, add an edge.
            addEdge(cardNumber, otherCard);
        }
    }
}

void addEdge(const string& card1, const string& card2) {
    adjList[card1].push_back(card2);
    adjList[card2].push_back(card1);
}


    vector<string> getNeighbors(const string& cardNumber) const {
        auto it = adjList.find(cardNumber);
        if (it != adjList.end()) {
            return it->second;
        }
        return {};
    }

    void bfsBlockUnblock(const string& startCard, bool block) {
        unordered_set<string> visited;
        queue<string> q;
        q.push(startCard);
        visited.insert(startCard);

        while (!q.empty()) {
            string cardNumber = q.front();
            q.pop();

            // Update card status
            blockedStatus[cardNumber] = block;

            for (const string& neighbor : getNeighbors(cardNumber)) {
                if (visited.find(neighbor) == visited.end()) {
                    q.push(neighbor);
                    visited.insert(neighbor);
                }
            }
        }
    }

    bool isBlocked(const string& cardNumber) const {
        auto it = blockedStatus.find(cardNumber);
        return it != blockedStatus.end() && it->second;
    }

    void setBlocked(const string& cardNumber, bool blocked) {
        blockedStatus[cardNumber] = blocked;
    }
};

splaytree creditSplayTree;
splaytree debitSplayTree;
avlTree avltree;
CardGraph cardGraph;

void loadCardsFromCSV(const string& filePath, splaytree& splayTree, avlTree& avltree, CardGraph& cardGraph) {
    ifstream file(filePath);
    string line;

    // Skip the header line
    getline(file, line);

    while (getline(file, line)) {
        if (line.empty()) continue; // Skip empty lines

        stringstream ss(line);
        string accountNumber, cardNumber, expirationDate, cvv, status, pin, issueDate, cardType, cardHolderName;

        getline(ss, accountNumber, ',');
        getline(ss, cardNumber, ',');
        getline(ss, expirationDate, ',');
        getline(ss, cvv, ',');
        getline(ss, status, ',');
        getline(ss, pin, ',');
        getline(ss, issueDate, ',');
        getline(ss, cardType, ',');
        getline(ss, cardHolderName, ',');

        string cardDetails = accountNumber + "," + cardNumber + "," + expirationDate + "," + cvv + "," + status + "," + pin + "," + issueDate + "," + cardType + "," + cardHolderName;

        splayTree.insert(cardNumber, cardDetails);
        avltree.insert(cardNumber, pin);
        cardGraph.addEdge(cardNumber, status == "blocked");
    }

    file.close();
}

void updateCSVFile(const string& filePath, splaytree& splayTree, avlTree& avltree, CardGraph& cardGraph) {
    ifstream file(filePath);
    ofstream tempFile("temp.csv");

    string line;
    getline(file, line); // read the header
    tempFile << line << endl; // write the header

    while (getline(file, line)) {
        if (line.empty()) continue; // Skip empty lines

        stringstream ss(line);
        string accountNumber, cardNumber, expirationDate, cvv, status, pin, issueDate, cardType, cardHolderName;

        getline(ss, accountNumber, ',');
        getline(ss, cardNumber, ',');
        getline(ss, expirationDate, ',');
        getline(ss, cvv, ',');
        getline(ss, status, ',');
        getline(ss, pin, ',');
        getline(ss, issueDate, ',');
        getline(ss, cardType, ',');
        getline(ss, cardHolderName, ',');

        // Ensure the line is complete before processing
        if (cardNumber.empty()) continue;

        splaynode* node = splayTree.search(cardNumber);
        if (node) {
            string newStatus = cardGraph.isBlocked(cardNumber) ? "blocked" : "active";
            string updatedDetails = accountNumber + "," + cardNumber + "," + expirationDate + "," + cvv + "," + newStatus + "," + pin + "," + issueDate + "," + cardType + "," + cardHolderName;
            node->cardDetails = updatedDetails; // Update the SplayTree node details
            tempFile << updatedDetails << endl;
        } else {
            // If the card is not found in the Splay Tree, write the original line
            tempFile << line << endl;
        }
    }

    file.close();
    tempFile.close();

    remove(filePath.c_str());
    rename("temp.csv", filePath.c_str());
}

void displayCardDetails(splaynode* node) {
    if (node) {
        stringstream ss(node->cardDetails);
        string accountNumber, cardNumber, expirationDate, cvv, status, pin, issueDate, cardType, cardHolderName;

        getline(ss, accountNumber, ',');
        getline(ss, cardNumber, ',');
        getline(ss, expirationDate, ',');
        getline(ss, cvv, ',');
        getline(ss, status, ',');
        getline(ss, pin, ',');
        getline(ss, issueDate, ',');
        getline(ss, cardType, ',');
        getline(ss, cardHolderName, ',');

        cout << "Account Number: " << accountNumber << endl;
        cout << "Card Number: " << cardNumber << endl;
        cout << "Expiration Date: " << expirationDate << endl;
        cout << "CVV: " << cvv << endl;
        cout << "Status: " << status << endl;
        cout << "PIN: " << pin << endl;
        cout << "Issue Date: " << issueDate << endl;
        cout << "Card Type: " << cardType << endl;
        cout << "Card Holder Name: " << cardHolderName << endl;
    } else {
        cout << "Card not found." << endl;
    }
}

void managePin(avlTree& avltree, const string& cardNumber, const string& newPin) {
    avltree.updatePin(cardNumber, newPin);
    cout << "PIN updated successfully." << endl;
}

void blockOrUnblockCard(CardGraph& cardGraph, const string& cardNumber, bool block) {
    cardGraph.bfsBlockUnblock(cardNumber, block);
    if (block) {
        cout << "Card blocked successfully." << endl;
    } else {
        cout << "Card unblocked successfully." << endl;
    }
}

// SplayTree, AVLTree, and Graph classes are assumed to be implemented as in the previous code.

void handleOperations(const string& debitCardFilePath, const string& creditCardFilePath, splaytree& debitSplayTree, splaytree& creditSplayTree, avlTree& avltree, CardGraph& cardGraph) {
    while (true) {
        cout << "Menu:\n"
             << "1. Display Card Details\n"
             << "2. Manage PIN\n"
             << "3. Block Card\n"
             << "4. Unblock Card\n"
             << "5. Exit\n"
             << "Enter your choice: ";
        int choice;
        cin >> choice;

        if (choice == 5) break;


        cout << "Enter card type (1 for debit, 2 for credit): ";
        int cardType;
        cin >> cardType;

        string cardFilePath = (cardType == 1) ? debitCardFilePath : creditCardFilePath;
        splaytree& splayTree = (cardType == 1) ? debitSplayTree : creditSplayTree;

        cout << "Enter card number: ";
        string cardNumber;
        cin >> cardNumber;

        switch (choice) {
            case 1: {
                splaynode* node = splayTree.search(cardNumber);
                displayCardDetails(node);
                break;
            }
            case 2: {
                cout << "Enter new PIN: ";
                string newPin;
                cin >> newPin;
                managePin(avltree, cardNumber, newPin);
                updateCSVFile(cardFilePath, splayTree, avltree, cardGraph);
                break;
            }
            case 3: {
                blockOrUnblockCard(cardGraph, cardNumber, true);
                updateCSVFile(cardFilePath, splayTree, avltree, cardGraph);
                break;
            }
            case 4: {
                blockOrUnblockCard(cardGraph, cardNumber, false);
                updateCSVFile(cardFilePath, splayTree, avltree, cardGraph);
                break;
            }
            default:
                cout << "Invalid choice." << endl;
        }
    }
}
class Graph{
private:
	vector<int> adj[100];
	int N;
	map<int, string> promotionName;
	map<string, int> cardVertex;

public:
	Graph(int n) : N(n) {}

	void addedge(int from, int to, string fromName, string toName) {
    	adj[from].push_back(to);
    	promotionName[from] = fromName;
    	promotionName[to] = toName;
    	cardVertex[fromName] = from;
    	cardVertex[toName] = to;
	}

	void topologicalsorting() {
    	Solution topoSorter;
    	vector<int> order = topoSorter.topoSort(N, adj);

    	cout << "Discounts based on Minimum Dependencies :" << endl<<endl;
    	cout<<"Card types \t\t\t Discount "<<endl;
    	for (int id : order) {
        	cout << promotionName[id] << "\t\t - " << id << "%" << endl;
    	}
	}
};
void showdiscounts() {
    Graph e(6); // Declare Graph e inside the case block
    e.addedge(5, 2, "Maestro Debit Cards", "Visa Debit Cards");
    e.addedge(5, 0, "Maestro Debit Cards", "Visa Electro DebitCards");
    e.addedge(4, 0, "RuPay Debit Cards", "Visa Electro DebitCards");
    e.addedge(4, 1, "RuPay Debit Cards", "Contactless Debit Cards");
    e.addedge(2, 3, "Visa Debit Cards", "MasterCard Debit Cards");
    e.addedge(3, 1, "MasterCard Debit Cards", "Contactless Debit Cards");
    e.topologicalsorting();
}
struct Loan {
    string loanid;
    string accountnumber;
    string type;
    double loanamount;
    double interestrate;
    int term;
    string status;
    string startdate;
    double remainingbalance;
};

class Splaytree {
private:
    struct Node {
        Loan data;
        Node* left;
        Node* right;
        Node(const Loan& loan) : data(loan), left(nullptr), right(nullptr) {}
    };
    Node* root;

    Node* rightRotate(Node* x) {
        Node* y = x->left;
        x->left = y->right;
        y->right = x;
        return y;
    }

    Node* leftRotate(Node* x) {
        Node* y = x->right;
        x->right = y->left;
        y->left = x;
        return y;
    }

    Node* splay(Node* root, const string& loanid) {
        if (!root || root->data.loanid == loanid) return root;

        if (loanid < root->data.loanid) {
            if (!root->left) return root;

            if (loanid < root->left->data.loanid) {
                root->left->left = splay(root->left->left, loanid);
                root = rightRotate(root);
            }
            else if (loanid > root->left->data.loanid) {
                root->left->right = splay(root->left->right, loanid);
                if (root->left->right)
                    root->left = leftRotate(root->left);
            }

            return (root->left) ? rightRotate(root) : root;
        } else {
            if (!root->right) return root;

            if (loanid > root->right->data.loanid) {
                root->right->right = splay(root->right->right, loanid);
                root = leftRotate(root);
            }
            else if (loanid < root->right->data.loanid) {
                root->right->left = splay(root->right->left, loanid);
                if (root->right->left)
                    root->right = rightRotate(root->right);
            }

            return (root->right) ? leftRotate(root) : root;
        }
    }

    Node* find_max(Node* node) {
        if (!node) return nullptr;
        while (node->right) {
            node = node->right;
        }
        return node;
    }

public:
    Splaytree() : root(nullptr) {}

    Loan* find_max() {
        if (!root) return nullptr;
        Node* max_node = find_max(root);
        return &(max_node->data);
    }

    void insert(const Loan& loan) {
        if (!root) {
            root = new Node(loan);
            return;
        }

        root = splay(root, loan.loanid);

        if (root->data.loanid == loan.loanid) return;

        Node* new_node = new Node(loan);
        if (loan.loanid < root->data.loanid) {
            new_node->right = root;
            new_node->left = root->left;
            root->left = nullptr;
        } else {
            new_node->left = root;
            new_node->right = root->right;
            root->right = nullptr;
        }
        root = new_node;
    }

    Loan* find(const string& loanid) {
        if (!root) return nullptr;
        root = splay(root, loanid);
        if (root->data.loanid == loanid) return &(root->data);
        return nullptr;
    }

    void erase(const string& loanid) {
        if (!root) return;

        root = splay(root, loanid);
        if (root->data.loanid != loanid) return;

        Node* temp = root;
        if (!root->left) {
            root = root->right;
        } else {
            root = splay(root->left, loanid);
            root->right = temp->right;
        }
        delete temp;
    }
};

void read_loans(Splaytree& loans) {
    ifstream file("loandetails.csv");
    string line;
    getline(file, line); // Read the header line

    while (getline(file, line)) {
        stringstream ss(line);
        Loan loan;
        string loanamount, interestrate, term;

        try {
            getline(ss, loan.loanid, ',');
            getline(ss, loan.accountnumber, ',');
            getline(ss, loan.type, ',');
            getline(ss, loanamount, ',');
            loan.loanamount = stod(loanamount);
            getline(ss, interestrate, ',');
            loan.interestrate = stod(interestrate);
            getline(ss, term, ',');
            loan.term = stoi(term);
            getline(ss, loan.status, ',');
            getline(ss, loan.startdate, ',');

            loan.remainingbalance = loan.loanamount; // Assuming remaining balance is the same as loan amount for simplicity

            loans.insert(loan);
        } catch (const std::exception& e) {
            cerr << "Error parsing line: " << line << endl;
            cerr << "Exception: " << e.what() << endl;
        }
    }
    file.close();
}

void calculate_interest(Splaytree& loans, unordered_map<string, double>& interest_amounts) {
    cout << "Interest calculation details:" << endl;
    cout << "---------------------------------" << endl;

    while (loans.find_max()) {
        Loan* loan = loans.find_max();
        double interest = loan->remainingbalance * (loan->interestrate / 100); // Convert interest rate to percentage
        interest_amounts[loan->loanid] = interest;

        cout << "Loan ID: " << loan->loanid << endl;
        cout << "Interest Amount: " << interest << endl;
        cout << "---------------------------------" << endl;

        loans.erase(loan->loanid);
    }
}

void write_interest_calculations(const unordered_map<string, double>& interest_amounts) {
    ofstream file("interest_calculations.csv");
    file << "loanid,interestamount\n";

    for (const auto& interest : interest_amounts) {
        file << interest.first << ',' << interest.second << '\n';
    }
    file.close();
}

class CreditCard {
private:
    string accountNumber;
    string cardNumber;
    string expirationDate;
    string cvv;
    string status;
    string pin;
    string issueDate;
    string cardType;
    string cardHolderName;

public:
    CreditCard(const string& accNum, const string& cardNum, const string& expDate, const string& cvv, const string& status,
               const string& pin, const string& issueDate, const string& cardType, const string& cardHolderName)
            : accountNumber(accNum), cardNumber(cardNum), expirationDate(expDate), cvv(cvv), status(status),
              pin(pin), issueDate(issueDate), cardType(cardType), cardHolderName(cardHolderName) {}

    string getCardNumber() const {
        return cardNumber;
    }

    string getCardType() const {
        return cardType;
    }
};

class CreditCardReader {
private:
    string filename;

public:
    CreditCardReader(const string& filename) : filename(filename) {}

    vector<CreditCard> readData() {
        vector<CreditCard> cards;
        ifstream infile(filename);
        if (!infile.is_open()) {
            cout << "Failed to open file: " << filename << endl;
            return cards;
        }

        string line;
        getline(infile, line); // Skip header
        while (getline(infile, line)) {
            stringstream ss(line);
            vector<string> tokens;
            string token;
            while (getline(ss, token, ',')) {
                tokens.push_back(token);
            }
            if (tokens.size() == 9) {
                cards.emplace_back(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5], tokens[6], tokens[7], tokens[8]);
            }
        }
        infile.close();
        return cards;
    }
};

class InterestCalculator {
private:
    map<string, double> interestRates;

public:
    InterestCalculator() {
        interestRates = {
            {"Regular Credit Card", 75000},
            {"Premium Credit Card", 375000},
            {"Commercial or Business Credit Card", 750000},
            {"CashBack Credit Card", 150000},
            {"Travel Credit Card", 225000},
            {"Shopping Credit Card", 112500},
            {"Fuel Credit Card", 187500}
        };
    }

    double calculateMonthlyInterest(const string& cardType) {
        return interestRates[cardType] / 12;
    }
};
void floydWarshall(vector<vector<long long>>& graph) {
    int n = graph.size();

    vector<vector<long long>> dist(graph);

    for (int k = 1; k < n; ++k) {
        for (int i = 1; i < n; ++i) {
            for (int j = 1; j < n; ++j) {
                if (dist[i][k] != LLONG_MAX && dist[k][j] != LLONG_MAX && dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }
    }

    cout << "Minimum revenue for each interest rate:\n\n";
    for (int i = 1; i < n; ++i) {
        for (int j = 1; j < n; ++j) {
            if (i != j) { // Skip diagonal values
                if (dist[i][j] != LLONG_MAX) {
                    cout << "From interest rate " << i << " to interest rate " << j << ": " << dist[i][j] << "\n";
                } else {
                    cout << "From interest rate " << i << " to interest rate " << j << ": Not reachable\n";
                }
            }
        }
        cout << endl; // Add a space after each group of results for each interest rate
    }
}


void revenueGeneratedForBank() {
    int nodes = 4; // Example static number of nodes
    int edges = 6; // Example static number of edges

    vector<vector<long long>> graph(nodes + 1, vector<long long>(nodes + 1, LLONG_MAX)); // Adjacency matrix representation of graph

    // Static input edges (x, y, weight)
    vector<tuple<int, int, long long>> static_edges = {
        make_tuple(1, 2, 800000),
        make_tuple(3, 1, 400000),
        make_tuple(1, 4, 150000),
        make_tuple(2, 3, 250000),
        make_tuple(4, 2, 200000),
        make_tuple(4, 3, 900000)
    };

    for (const auto& edge : static_edges) {
        int x, y;
        long long weight;
        tie(x, y, weight) = edge;
        graph[x][y] = weight;
        graph[y][x] = weight; // For undirected graph
    }

    // Initialize diagonal elements to 0
    for (int i = 1; i <= nodes; ++i) {
        graph[i][i] = 0;
    }

    floydWarshall(graph);
}

int interestmanagement() {
    int choice;
    Splaytree loans;
    unordered_map<string, double> interest_amounts;

    do {
        cout << "Menu:" << endl;
        cout << "1. Calculate interest for loans" << endl;
        cout << "2. Revenue Generated for Bank" << endl;
        cout << "3. Calculate interest for credit cards" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                // Calculate interest for loans
                read_loans(loans);
                calculate_interest(loans, interest_amounts);
                write_interest_calculations(interest_amounts);
                cout << "Interest calculated and recorded successfully in interest_calculations.csv." << endl;
                cout<<"-------------------------------------\n";
                break;
            case 2:
                revenueGeneratedForBank();
                cout<<"-------------------------------------\n";
                break;
            case 3: {
                ifstream infile("creditcard.csv");
                CreditCardReader reader("creditcard.csv");
                vector<CreditCard> cards = reader.readData();

                InterestCalculator calculator;
                cout << "Card Number\t\tInterest Amount" << endl;

                ofstream outfile("interestforcards.csv");
                if (!outfile.is_open()) {
                    cout << "Failed to open output file!" << endl;
                    return 1;
                }

                outfile << "card_number,interest_amount" << endl;

                for (const auto& card : cards) {
                    double interestAmount = calculator.calculateMonthlyInterest(card.getCardType());
                    cout << card.getCardNumber() << "\t\t" << interestAmount << endl;
                    outfile << card.getCardNumber() << "," << interestAmount << endl;
                }

                outfile.close();
                cout<<"-------------------------------------\n";

                break;
            }
            case 4:
                cout << "Exiting the program. Goodbye!" << endl;
                cout<<"-------------------------------------\n";
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                cout<<"-------------------------------------\n";
        }
                cout<<"-------------------------------------\n";
    } while (choice != 4);

    return 0;
}
string generateAccountNumber() {
    srand(static_cast<unsigned int>(time(nullptr)));
    string accountNumber;
    for (int i = 0; i < 10; ++i) {
        accountNumber += to_string(rand() % 10);
    }
    return accountNumber;
}
class BankAccount {
private:
    string account_number;
    string account_holder;
    string address;
    int phone_number;
    string mail_id;
    int PAN_number;
    string type;
    double balance;
    time_t date_of_creation;
    string status;
    int cibil_score;

public:
    // Constructor
    BankAccount(string accNumber, string accHolder, string addr, int phone, string mail, int pan,
                string accType, double bal, time_t creationDate, string stat = "active", int cibil = 0)
        : account_number(accNumber), account_holder(accHolder), address(addr), phone_number(phone),
          mail_id(mail), PAN_number(pan), type(accType), balance(bal), date_of_creation(creationDate),
          status(stat), cibil_score(cibil) {
    }

    void update(const string& filename) {
        int ch;
        cout << "\nSelect the account detail to update:\n";
        cout << "1. Phone Number\n";
        cout << "2. Address\n";
        cout << "3. Mail ID\n";
        cout << "Enter your choice: ";
        cin >> ch;

        switch (ch) {
            case 1: {
                cout << "Enter new Phone Number: ";
                cin >> phone_number;
                updateCSVField(filename, "phone_number", to_string(phone_number));
                break;
            }
            case 2: {
                cout << "Enter new Address: ";
                cin.ignore();
                getline(cin, address);
                updateCSVField(filename, "address", address);
                break;
            }
            case 3: {
                cout << "Enter new Mail ID: ";
                cin.ignore();
                getline(cin, mail_id);
                updateCSVField(filename, "mail_id", mail_id);
                break;
            }
            default:
                cerr << "Invalid choice. No update performed." << endl;
        }
    }

    void display() const {
        cout << "Account Number: " << account_number << endl;
        cout << "Account Holder: " << account_holder << endl;
        cout << "Address: " << address << endl;
        cout << "Phone Number: " << phone_number << endl;
        cout << "Mail ID: " << mail_id << endl;
        cout << "PAN Number: " << PAN_number << endl;
        cout << "Account Type: " << type << endl;
        cout << "Balance: " << balance << endl;
        cout << "Date of Creation: " << ctime(&date_of_creation);
        cout << "Status: " << status << endl;
        cout << "CIBIL Score: " << cibil_score << endl;
    }

    string getAccountNumber() const {
        return account_number;
    }

    void saveToCSV(const string& filename) const {
        ifstream inFile(filename);
        ofstream tempFile("temp.csv");
        string line;

        // Copy the headers from the original file to the temp file
        if (getline(inFile, line)) {
            tempFile << line << endl;
        }

        bool updated = false;
        while (getline(inFile, line)) {
            stringstream ss(line);
            string temp;
            string account_number;
            getline(ss, temp, ',');
            account_number = temp;
            if (account_number == this->account_number) {
                // Write the updated account details to the temp file
                tempFile << this->account_number << "," << this->account_holder << "," << this->address << "," << this->phone_number << ","
                         << this->mail_id << "," << this->PAN_number << "," << this->type << "," << this->balance << "," << this->date_of_creation << "," << this->status << "," << this->cibil_score << "\n";
                updated = true;
            } else {
                // Copy the original line to the temp file
                tempFile << line << endl;
            }
        }

        // If the account was not found, append it to the temp file
        if (!updated) {
            tempFile << this->account_number << "," << this->account_holder << "," << this->address << "," << this->phone_number << ","
                     << this->mail_id << "," << this->PAN_number << "," << this->type << "," << this->balance << "," << this->date_of_creation << "," << this->status << "," << this->cibil_score << "\n";
        }

        inFile.close();
        tempFile.close();

        // Replace the original file with the temp file
        remove(filename.c_str());
        rename("temp.csv", filename.c_str());
    }
    void updateCSVField(const string& filename, const string& field, const string& newValue) {
        ifstream inFile(filename);
        ofstream tempFile("temp.csv");
        string line;

        // Copy the headers from the original file to the temp file
        if (getline(inFile, line)) {
            tempFile << line << endl;
        }

        while (getline(inFile, line)) {
            stringstream ss(line);
            string temp;
            string account_number;
            getline(ss, temp, ',');
            account_number = temp;
            if (account_number == this->account_number) {
                stringstream lineStream;
                lineStream << this->account_number << ",";
                lineStream << this->account_holder << ",";
                if (field == "address") {
                    lineStream << newValue << ",";
                } else {
                    lineStream << this->address << ",";
                }
                if (field == "phone_number") {
                    lineStream << newValue << ",";
                } else {
                    lineStream << this->phone_number << ",";
                }
                if (field == "mail_id") {
                    lineStream << newValue << ",";
                } else {
                    lineStream << this->mail_id << ",";
                }
                lineStream << this->PAN_number << ",";
                lineStream << this->type << ",";
                lineStream << this->balance << ",";
                lineStream << this->date_of_creation << ",";
                lineStream << this->status << "\n";
                lineStream << this->cibil_score << "\n";
                tempFile << lineStream.str();
            } else {
                tempFile << line << endl;
            }
        }

        inFile.close();
        tempFile.close();

        // Replace the original file with the temp file
        remove(filename.c_str());
        rename("temp.csv", filename.c_str());
    }
    int getCIBILScore() const {
        return cibil_score;
    }
};

bool loadAccountFromCSV(const string& accNumber, BankAccount& account, const string& filename) {
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string temp;
        string account_number;
        getline(ss, temp, ',');
        account_number = temp;
        if (account_number == accNumber) {
            string account_holder, address, mail_id, type, status;
            int phone_number, PAN_number, cibil_score;
            double balance;
            time_t date_of_creation;
            getline(ss, account_holder, ',');
            getline(ss, address, ',');
            getline(ss, temp, ',');
            phone_number = stoi(temp);
            getline(ss, mail_id, ',');
            getline(ss, temp, ',');
            PAN_number = stoi(temp);
            getline(ss, type, ',');
            getline(ss, temp, ',');
            balance = stod(temp);
            getline(ss, temp, ',');
            date_of_creation = stol(temp);
            getline(ss, status, ',');
            getline(ss, temp, ',');
            cibil_score = stoi(temp);
            account = BankAccount(account_number, account_holder, address, phone_number, mail_id, PAN_number, type, balance, date_of_creation, status, cibil_score);
            return true;
        }
    }
    return false;
}


void closeAccountFromCSV(const string& accNumber, const string& filename) {
    ifstream file(filename);
    ofstream tempFile("temp.csv");
    string line;

    // Copy the headers from the original file to the temp file
    if (getline(file, line)) {
        tempFile << line << endl;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        string temp;
        string account_number;
        getline(ss, temp, ',');
        account_number = temp;
        if (account_number != accNumber) {
            tempFile << line << "\n";
        } else {
            // Update the status to 'closed'
            string account_holder, address, mail_id, type;
            int phone_number, PAN_number, cibil_score;
            double balance;
            time_t date_of_creation;
            string status = "closed";
            getline(ss, account_holder, ',');
            getline(ss, address, ',');
            getline(ss, temp, ',');
            phone_number = stoi(temp);
            getline(ss, mail_id, ',');
            getline(ss, temp, ',');
            PAN_number = stoi(temp);
            getline(ss, type, ',');
            getline(ss, temp, ',');
            balance = stod(temp);
            getline(ss, temp, ',');
            date_of_creation = stol(temp);
            getline(ss, temp, ',');
            cibil_score = stoi(temp);
            tempFile << account_number << "," << account_holder << "," << address << "," << phone_number << "," << mail_id << "," << PAN_number << "," << type << "," << balance << "," << date_of_creation << "," << status << "," << cibil_score << "\n";
        }
    }

    file.close();
    tempFile.close();
    remove(filename.c_str());
    rename("temp.csv", filename.c_str());
}

void createAccount(const string& filename, MaxHeap& cibil_heap) {
    int phone, pan, cibil;
    string accHolder, addr, accType, mailID;
    double balance;
    string accountNumber = generateAccountNumber();
    cout << "Enter Account Holder: ";
    cin.ignore(); // Clear the newline character from the buffer
    getline(cin, accHolder);
    cout << "Enter Address: ";
    getline(cin, addr);
    cout << "Enter Phone Number: ";
    cin >> phone;
    cout << "Enter PAN Number: ";
    cin >> pan;
    cout << "Enter Account Type (Student/Joint/Savings/Business/Checking): ";
    cin >> accType;
    cout << "Enter Initial deposit: ";
    cin >> balance;
    cout << "Enter Mail ID: ";
    cin.ignore(); // Clear the newline character from the buffer
    getline(cin, mailID);
    cibil=900;
    time_t now = time(0);
    BankAccount account(accountNumber, accHolder, addr, phone, mailID, pan, accType, balance, now, "active", cibil);
    account.saveToCSV(filename);
    cout << "Your Account Number: " << accountNumber << endl;
    cout << "Account created successfully!" << endl;
    // Add account to max heap
    cibil_heap.insert(HeapNode(accountNumber, cibil));
}

void runBankingApp() {
    int choice;
    string filename = "accountDetails.csv";
    string fname = "customers_data.csv";
    MaxHeap cibil_heap;
    ServiceSystem serviceSystem;
    AuthenticationSystem authSystem(fname);
    // Load account details from CSV file and insert into the max heap
    ifstream file(filename);
    string line;
     queue<UpdateRequest> updateRequestsQueue;
    string transactionFile = "transactions.csv";
    string accountDetailsFile = "accountDetails.csv";
    // Skip header line
    getline(file, line);
    while (getline(file, line)) {
        stringstream ss(line);
        string accountNumber, accountHolder, address, accountType, mailID;
        int phoneNumber, PANNumber, cibilScore;
        double balance;
        time_t dateOfCreation;
        string status;

        getline(ss, accountNumber, ',');
        getline(ss, accountHolder, ',');
        getline(ss, address, ',');
        ss >> phoneNumber; ss.ignore();
        getline(ss, mailID, ',');
        ss >> PANNumber; ss.ignore();
        getline(ss, accountType, ',');
        ss >> balance; ss.ignore();
        ss >> dateOfCreation; ss.ignore();
        getline(ss, status, ',');
        ss >> cibilScore; ss.ignore();

        cibil_heap.insert(HeapNode(accountNumber, cibilScore));
    }
    file.close();

    bool authenticated = false;
    bool authenticated2 = false;
    Services services;
    AdminSystem adminSystem("admin", "admin123");
    // Initial menu for account creation or login
    while (!authenticated) {
        cout << "1. Create Account\n";
        cout << "2. Admin Login\n";
        cout << "3. User Login\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                createAccount(filename, cibil_heap);
                serviceSystem.promptAndStoreData();
                authenticated = true;
                cout<<"-------------------------------------\n";
                break;
            case 2:
                adminSystem.adminLogin();
                authenticated2=true;
                authenticated = true; // Assume login is successful for simplicity
                cout<<"-------------------------------------\n";
                break;
            case 3:
                services.login();
                authenticated = true; // Assume login is successful for simplicity
                cout<<"-------------------------------------\n";
                break;
            case 4:
                cout << "Exiting program. Goodbye!" << endl;
                cout<<"-------------------------------------\n";
                return;
            default:
                cerr << "Invalid choice. Please enter a valid option." << endl;
                cout<<"-------------------------------------\n";
        }
    }
    if (authenticated2){
    do{
        cout << "1. Interest Calculation\n";
        cout << "2. View Transaction\n";
        cout << "3. Loan Management\n";
        cout << "4. Manage Card\n";
        cout << "5. Get Optimized Path\n";
        cout << "6. Administration\n";
        cout << "7. Exit.\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                interestmanagement();
                break;
            case 2:{
                cout << "------------Transaction History------------" << endl;
                ifstream file(transactionFile);
                if (!file.is_open()) {
                    cerr << "Error: Unable to open transaction file." << endl;
                    break;
                }
                string line;
                while (getline(file, line)) {
                    cout<<" "<< line <<" "<<endl;
                }
                cout<<"---------------------------------------------\n";
                break;
        }
            case 3:
                admin();
                cout<<"-------------------------------------\n";
                break;
            case 4:{
                CardManagement manager("debitcards.csv", "creditcards.csv");
                manager.runCardManagementSystem();
                cout<<"-------------------------------------\n";
                break;}
            case 5:{
                runBankNetwork();
                cout<<"-------------------------------------\n";
                break;}
            case 6:
                administration();
                cout<<"-------------------------------------\n";
                break;
            case 7:
                cout << "Exiting program. Goodbye!" << endl;
                cout<<"-------------------------------------\n";
                break;
            default:
                cerr << "Invalid choice. Please enter a valid option." << endl;
                cout<<"-------------------------------------\n";
        }
                cout<<"-------------------------------------\n";
        }while(choice!=7);
    }
    else{
    do {
        cout << "\nMain Menu:\n";
        cout << "1. Update Account Details\n";
        cout << "2. Display Account Details\n";
        cout << "3. Deposit Amount\n";
        cout << "4. Withdraw Amount\n";
        cout << "5. Close Account\n";
        cout << "6. Check Loan Eligibility\n";
        cout << "7. Check discount for cards\n";
        cout << "8. Get Loan\n";
        cout << "9. Make Loan Payment\n";
        cout << "10. View Loan statement\n";
        cout << "11. Manage Card\n";
        cout << "12. Customer Support\n";
        cout << "13. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {

                string accNumber,mpin;
                cout << "Enter Account Number: ";
                cin >> accNumber;
                cout << "Enter your MPIN: ";
                cin >> mpin;
                bool confirmation;
                confirmation=authSystem.authenticate(accNumber,mpin);
                BankAccount account("", "", "", 0, "", 0, "", 0, 0);
                if (confirmation){
                if (loadAccountFromCSV(accNumber, account, filename)) {
                    account.update(filename);
                } else {
                    cerr << "Account not found" << endl;
                }}
                cout<<"-------------------------------------\n";
                break;
            }
            case 2: {
                string accNumber;
                cout << "Enter Account Number: ";
                cin >> accNumber;
                BankAccount account("", "", "", 0, "", 0, "", 0, 0);
                if (loadAccountFromCSV(accNumber, account, filename)) {
                    account.display();
                } else {
                    cerr << "Account not found" << endl;
                }
                cout<<"-------------------------------------\n";
                break;
            }
            case 3: {
                long long depositAccNum; // Changed to long long
                double depositAmount;
                string mpin;
                cout << "Enter account number: ";
                cin >> depositAccNum;
                string acNum=to_string(depositAccNum);
                cout << "Enter amount to deposit: ";
                cin >> depositAmount;
                cout << "Enter your MPIN: ";
                cin >> mpin;
                bool confirmation;
                confirmation=authSystem.authenticate(acNum,mpin);
                if(confirmation){
                updateRequestsQueue.push({depositAccNum, depositAmount, "deposit", chrono::system_clock::to_time_t(chrono::system_clock::now())});
                performTransaction(accountDetailsFile, depositAccNum, depositAmount, "deposit");
                writeTransaction(transactionFile, updateRequestsQueue.back());
                cout <<depositAmount<<" Deposited successfully\n";}
                cout<<"-------------------------------------\n";
                break;
            }
            case 4: {
                long long withdrawAccNum; // Changed to long long
                double withdrawAmount;
                string mpin;
                cout << "Enter account number: ";
                cin >> withdrawAccNum;
                string acNum=to_string(withdrawAccNum);
                cout << "Enter amount to withdraw: ";
                cin >> withdrawAmount;
                cout << "Enter your MPIN: ";
                cin >> mpin;
                bool confirmation;
                confirmation=authSystem.authenticate(acNum,mpin);
                if(confirmation){
                updateRequestsQueue.push({withdrawAccNum, withdrawAmount, "withdraw", chrono::system_clock::to_time_t(chrono::system_clock::now())});
                performTransaction(accountDetailsFile, withdrawAccNum, withdrawAmount, "withdraw");
                writeTransaction(transactionFile, updateRequestsQueue.back());
                cout <<withdrawAmount<<" Withdrawed successfully\n";}
                cout<<"-------------------------------------\n";
                break;
            }
            case 5: {
                string accNumber;
                cout << "Enter Account Number to close: ";
                cin >> accNumber;
                closeAccountFromCSV(accNumber, filename);
                cout << "Account closed successfully!" << endl;
                cout<<"-------------------------------------\n";
                break;
            }
            case 6: {
                string accNumber;
                cout << "Enter Account Number: ";
                cin >> accNumber;
                bool found = false;
                int height = 0;
                // Check if the account number is in the heap and get its height
                for (auto node : cibil_heap.getHeap()) {
                    if (node.account_number == accNumber) {
                        found = true;
                        // Assuming the height is equal to the index of the node + 1
                        height = &node - &cibil_heap.getHeap()[0] + 1;
                        break;
                    }
                }
                if (found && height <= 2) {
                    cout << "Congratulations! You are eligible to get a loan." << endl;
                } else {
                    cout << "Sorry, you are not eligible to get a loan." << endl;
                }
                cout<<"-------------------------------------\n";
                break;
            }
            case 7:
                showdiscounts();
                cout<<"-------------------------------------\n";
                break;
            case 8:
                createloan();
                cout<<"-------------------------------------\n";
                break;
            case 9:{
                loanpayment();
                cout<<"-------------------------------------\n";
                break;}
            case 10:{
                viewloanpayments();
                cout<<"-------------------------------------\n";
                break;}
            case 12 :
            {
                runSupportSystem();
                cout<<"-------------------------------------\n";
                break;}
            case 11:{
                const string debitCardFilePath = "debitcards.csv";
                const string creditCardFilePath = "creditcards.csv";

                splaytree debitSplayTree;
                splaytree creditSplayTree;
                avlTree avlTree;
                CardGraph cardGraph;

                // Load cards from CSV files and initialize the trees and graph
                loadCardsFromCSV(debitCardFilePath, debitSplayTree, avlTree, cardGraph);
                loadCardsFromCSV(creditCardFilePath, creditSplayTree, avlTree, cardGraph);

                handleOperations(debitCardFilePath, creditCardFilePath, debitSplayTree, creditSplayTree, avlTree, cardGraph);
                cout<<"-------------------------------------\n";
                break;}
            case 13:
                cout << "Exiting program. Goodbye!" << endl;
                cout<<"-------------------------------------\n";
                break;
            default:
                cerr << "Invalid choice. Please enter a valid option." << endl;
                cout<<"-------------------------------------\n";
                break;
        }
                cout<<"-------------------------------------\n";
    } while (choice != 13);
    }
}
int main() {
    cout<<"-------------------------------------\n";
cout<<"Welcome to Banking System Simulator\n";

cout<<"-------------------------------------\n";
    runBankingApp();
    return 0;
}
