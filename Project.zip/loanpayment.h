#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <ctime>
#include <vector>
#include <algorithm>
#include <stdexcept>

using namespace std;

struct payments {
    int loanID;
    double interestAmount;

    payments(int id, double amount) : loanID(id), interestAmount(amount) {}
};

class payment {
private:
    vector<payments> loanpay;
    string interestFilename = "interest_calculations.csv";

public:
    void loadPaymentsFromFile() {
        ifstream file(interestFilename);
        if (!file.is_open()) {
            cerr << "Failed to open file: " << interestFilename << endl;
            return;
        }

        string line;
        getline(file, line); // Skip header line
        while (getline(file, line)) {
            stringstream ss(line);
            string loanID_str, interestAmount_str;
            if (getline(ss, loanID_str, ',') && getline(ss, interestAmount_str, ',')) {
                try {
                    int loanID = stoi(loanID_str);
                    double interestAmount = stod(interestAmount_str);
                    loanpay.push_back(payments(loanID, interestAmount));
                } catch (const invalid_argument& e) {
                    cerr << "Invalid data in file: " << line << endl;
                    continue;
                } catch (const out_of_range& e) {
                    cerr << "Data out of range in file: " << line << endl;
                    continue;
                }
            }
        }

        file.close();
    }

    void makePayment() {
        int loanID;
        double paymentAmount;

        cout << "Enter Loan ID for payment: ";
        cin >> loanID;

        auto it = find_if(loanpay.begin(), loanpay.end(), [loanID](const payments& p) {
            return p.loanID == loanID;
        });

        if (it == loanpay.end()) {
            cout << "No payment due for Loan ID: " << loanID << endl;
            return;
        }

        double interestAmount = it->interestAmount;
        cout << "Interest Amount due: " << interestAmount << endl;

        cout << "Enter payment amount: ";
        cin >> paymentAmount;

        string loanFilename = "loan_" + to_string(loanID) + ".txt";
        ifstream loanFile(loanFilename);
        if (!loanFile.is_open()) {
            cerr << "Failed to open loan file: " << loanFilename << endl;
            return;
        }

        vector<string> lines;
        string line;
        while (getline(loanFile, line)) {
            lines.push_back(line);
        }
        loanFile.close();

        if (lines.empty()) {
            cerr << "Loan file is empty." << endl;
            return;
        }

        int nl;
        nl=stoi(lines[0]);
        // Ensure there are enough lines to read the current amount
        if (9 + nl - 1 >= lines.size()) {
            cerr << "Loan file does not have expected number of lines." << endl;
            return;
        }


    double currentAmount = 0.0;
    bool validLineFound = false;
    for (int i = 9; i < lines.size(); ++i) {
        stringstream st(lines[i]);
        string data;
        try {
            getline(st, data, ','); // Skip payment amount
            if (getline(st, data, ',')) {
                currentAmount = stod(data);
                validLineFound = true;
                break;
            }
        } catch (const invalid_argument& e) {
                cerr << "Invalid number format in line: " << lines[i] << endl;
                cerr << "Line content: " << lines[i] << endl;
        } catch (const out_of_range& e) {
                cerr << "Number out of range in line: " << lines[i] << endl;
                cerr << "Line content: " << lines[i] << endl;
            }
        }

        if (!validLineFound) {
            cerr << "No valid lines found to process current amount." << endl;
            return;
        }

        if (paymentAmount > currentAmount) {
            cout << "Payment amount exceeds loan amount!" << endl;
            return;
        }
        currentAmount -= paymentAmount;

        // Update the first line to nl + 1
        lines[0] = to_string(nl + 1);

        // Append the new payment record
        time_t now = time(0);
        tm* timeinfo = localtime(&now);
        char date[80];
        strftime(date, 80, "%Y-%m-%d %H:%M:%S", timeinfo);

        stringstream newRecord;
        newRecord << paymentAmount << "," << currentAmount << "," << date;
        lines.push_back(newRecord.str());

        // Write the updated content back to the file
        ofstream updatedLoanFile(loanFilename);
        if (!updatedLoanFile.is_open()) {
            cerr << "Failed to open loan file for writing: " << loanFilename << endl;
            return;
        }

        for (const auto& l : lines) {
            updatedLoanFile << l << endl;
        }

        updatedLoanFile.close();

        cout << "Payment of " << paymentAmount << " made for Loan ID: " << loanID << endl;
        cout << "Updated Loan Amount: " << currentAmount << endl;
    }

    void getLoanStatement() {
        int loanid;
        cout<<"Enter the Loan ID:";
        cin>>loanid;
        string loanFilename = "loan_" + to_string(loanid) + ".txt";
        ifstream loanFile(loanFilename);
        if (!loanFile.is_open()) {
            cerr << "Loan statement not found for Loan ID: " << loanid << endl;
            return;
        }

        cout << "Loan Statement for Loan ID: " << loanid << endl;
        string line;
        while (getline(loanFile, line)) {
            cout << line << endl;
        }

        loanFile.close();
    }
};

void loanpayment(){
    payment pay;
    pay.loadPaymentsFromFile();
    pay.makePayment();
    return;
}

void viewloanpayments(){
    payment pay;
    pay.getLoanStatement();
    return;
}
