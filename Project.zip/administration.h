#include <iostream>
#include <vector>
#include <list>
#include <stack>
#include <queue>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <string>
#include <random>

using namespace std;

// Define a structure for an employee
struct Employee {
    int id;
    string name;
    string designation;
    double salary;
    string branchName;
};

// Define a structure for an ATM
struct ATM {
    string location;
    int cash;
};

// Define a structure for a branch
struct Branch {
    string name;
    string location;
    int numOfEmployees;
    int numOfATMs;
};

// Define a structure for a hardware component
struct HardwareComponent {
    int id;
    string name;
    double price;
    string branch_name;
    string branch_location;
};

// Function to read branches from a file
vector<Branch> readBranchesFromFile(const string& filename) {
    vector<Branch> branches;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return branches;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        Branch branch;
        getline(ss, branch.name, ',');
        getline(ss, branch.location, ',');
        branches.push_back(branch);
    }
    file.close();
    return branches;
}

// Function to generate a unique employee ID
int generateEmpID(const list<Employee>& employees) {
    return employees.empty() ? 1 : employees.back().id + 1;
}

// Function to generate a unique ID for hardware components
int generateComponentID(const vector<HardwareComponent>& components) {
    static random_device rd;
    static mt19937 gen(rd());
    uniform_int_distribution<int> dis(1, 10000);

    int componentID;
    do {
        componentID = dis(gen);
    } while (find_if(components.begin(), components.end(), [componentID](const HardwareComponent& comp) {
        return comp.id == componentID;
    }) != components.end());

    return componentID;
}

// Function to load employee data from file
list<Employee> loadEmployees(const string& filename) {
    list<Employee> employees;
    ifstream file(filename);
    if (file.is_open()) {
        Employee emp;
        while (file >> emp.id >> emp.name >> emp.designation >> emp.salary >> emp.branchName) {
            employees.push_back(emp);
        }
        file.close();
    }
    return employees;
}

// Function to save employee data to file
void saveEmployees(const list<Employee>& employees, const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        for (const auto& emp : employees) {
            file << emp.id << " " << emp.name << " " << emp.designation << " " << emp.salary << " " << emp.branchName << endl;
        }
        file.close();
        cout << "Employee details saved successfully." << endl;
    } else {
        cout << "Unable to open file for saving employee details." << endl;
    }
}

// Function to load ATM data from file
stack<ATM> loadATMs(const string& filename) {
    stack<ATM> atms;
    ifstream file(filename);
    if (file.is_open()) {
        ATM atm;
        while (file >> atm.location >> atm.cash) {
            atms.push(atm);
        }
        file.close();
    }
    return atms;
}

// Function to save ATM data to file
void saveATMs(const stack<ATM>& atms, const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        stack<ATM> tempAtms = atms;
        while (!tempAtms.empty()) {
            const ATM& atm = tempAtms.top();
            file << atm.location << " " << atm.cash << endl;
            tempAtms.pop();
        }
        file.close();
        cout << "ATM details saved successfully." << endl;
    } else {
        cout << "Unable to open file for saving ATM details." << endl;
    }
}

// Function to load branch data from file
queue<Branch> loadBranches(const string& filename) {
    queue<Branch> branches;
    ifstream file(filename);
    if (file.is_open()) {
        Branch branch;
        while (file >> branch.name >> branch.location >> branch.numOfEmployees >> branch.numOfATMs) {
            branches.push(branch);
        }
        file.close();
    }
    return branches;
}

// Function to save branch data to file
void saveBranches(const queue<Branch>& branches, const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        queue<Branch> tempBranches = branches;
        while (!tempBranches.empty()) {
            const Branch& branch = tempBranches.front();
            file << branch.name << " " << branch.location << " " << branch.numOfEmployees << " " << branch.numOfATMs << endl;
            tempBranches.pop();
        }
        file.close();
        cout << "Branch details saved successfully." << endl;
    } else {
        cout << "Unable to open file for saving branch details." << endl;
    }
}

// Function to add a new employee
void addEmployee(list<Employee>& employees, const queue<Branch>& branches) {
    Employee emp;
    emp.id = generateEmpID(employees); // Generate ID automatically
    cout << "Enter employee name: ";
    cin >> emp.name;
    cout << "Enter employee designation: ";
    cin >> emp.designation;
    cout << "Enter employee salary: ";
    cin >> emp.salary;

    // List branches for the user to select from
    cout << "Available branches:" << endl;
    queue<Branch> tempBranches = branches;
    while (!tempBranches.empty()) {
        const Branch& branch = tempBranches.front();
        cout << "Branch Name: " << branch.name << ", Location: " << branch.location << endl;
        tempBranches.pop();
    }

    cout << "Enter the branch name where the employee will be assigned: ";
    cin >> emp.branchName;

    employees.push_back(emp);
    cout << "Employee added successfully." << endl;
}

// Function to view all employees
void viewEmployees(const list<Employee>& employees) {
    cout << "\nEmployee List:" << endl;
    for (const auto& emp : employees) {
        cout << "ID: " << emp.id << ", Name: " << emp.name << ", Designation: " << emp.designation << ", Salary: " << emp.salary << ", Branch: " << emp.branchName << endl;
    }
}

// Function to view a specific employee by ID
void viewEmployeeByID(const list<Employee>& employees, int id) {
    auto it = find_if(employees.begin(), employees.end(), [id](const Employee& emp) {
        return emp.id == id;
    });
    if (it != employees.end()) {
        cout << "ID: " << it->id << ", Name: " << it->name << ", Designation: " << it->designation << ", Salary: " << it->salary << ", Branch: " << it->branchName << endl;
    } else {
        cout << "Employee with ID " << id << " not found." << endl;
    }
}

// Function to update an employee's salary
void updateSalary(list<Employee>& employees) {
    int id;
    double newSalary;
    cout << "Enter the ID of the employee whose salary you want to update: ";
    cin >> id;
    auto it = find_if(employees.begin(), employees.end(), [&id](const Employee& emp) {
        return emp.id == id;
    });
    if (it != employees.end()) {
        cout << "Enter the new salary for " << it->name << ": ";
        cin >> newSalary;
        it->salary = newSalary;
        cout << "Salary updated successfully." << endl;
    } else {
        cout << "Employee with ID " << id << " not found." << endl;
    }
}

// Function to delete an employee by ID
void deleteEmployee(list<Employee>& employees) {
    int id;
    cout << "Enter the ID of the employee you want to delete: ";
    cin >> id;
    auto it = find_if(employees.begin(), employees.end(), [&id](const Employee& emp) {
        return emp.id == id;
    });
    if (it != employees.end()) {
        employees.erase(it);
        cout << "Employee with ID " << id << " deleted successfully." << endl;
    } else {
        cout << "Employee with ID " << id << " not found." << endl;
    }
}

// Function to add a new ATM
void addATM(stack<ATM>& atms) {
    ATM atm;
    cout << "Enter ATM location: ";
    cin >> atm.location;
    cout << "Enter cash amount: ";
    cin >> atm.cash;
    atms.push(atm);
    cout << "ATM added successfully." << endl;
}

// Function to view all ATMs
void viewATMs(const stack<ATM>& atms) {
    cout << "\nATM List:" << endl;
    stack<ATM> tempAtms = atms;
    while (!tempAtms.empty()) {
        const ATM& atm = tempAtms.top();
        cout << "Location: " << atm.location << ", Cash: " << atm.cash << endl;
        tempAtms.pop();
    }
}

// Function to add a new branch
void addBranch(queue<Branch>& branches) {
    Branch branch;
    cout << "Enter branch name: ";
        cin >> branch.name;
    cout << "Enter branch location: ";
    cin >> branch.location;
    cout << "Enter number of employees: ";
    cin >> branch.numOfEmployees;
    cout << "Enter number of ATMs: ";
    cin >> branch.numOfATMs;
    branches.push(branch);
    cout << "Branch added successfully." << endl;
}

// Function to view all branches
void viewBranches(const queue<Branch>& branches) {
    cout << "\nBranch List:" << endl;
    queue<Branch> tempBranches = branches;
    while (!tempBranches.empty()) {
        const Branch& branch = tempBranches.front();
        cout << "Name: " << branch.name << ", Location: " << branch.location
             << ", Number of Employees: " << branch.numOfEmployees
             << ", Number of ATMs: " << branch.numOfATMs << endl;
        tempBranches.pop();
    }
}

// Function to load hardware components from file
vector<HardwareComponent> loadHardwareComponents(const string& filename) {
    vector<HardwareComponent> components;
    ifstream file(filename);
    if (file.is_open()) {
        HardwareComponent component;
        while (file >> component.id >> component.name >> component.price >> component.branch_name >> component.branch_location) {
            components.push_back(component);
        }
        file.close();
    }
    return components;
}

// Function to save hardware components to file
void saveHardwareComponents(const vector<HardwareComponent>& components, const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        for (const auto& component : components) {
            file << component.id << " " << component.name << " " << component.price << " " << component.branch_name << " " << component.branch_location << endl;
        }
        file.close();
        cout << "Hardware component details saved successfully." << endl;
    } else {
        cout << "Unable to open file for saving hardware component details." << endl;
    }
}

// Function to add a new hardware component
void addHardwareComponent(vector<HardwareComponent>& components, const queue<Branch>& branches) {
    HardwareComponent component;
    component.id = generateComponentID(components); // Generate ID automatically
    cout << "Enter hardware component name: ";
    cin >> component.name;
    cout << "Enter hardware component price: ";
    cin >> component.price;

    // List branches for the user to select from
    cout << "Available branches:" << endl;
    queue<Branch> tempBranches = branches;
    while (!tempBranches.empty()) {
        const Branch& branch = tempBranches.front();
        cout << "Branch Name: " << branch.name << ", Location: " << branch.location << endl;
        tempBranches.pop();
    }

    cout << "Enter the branch name where the hardware component will be assigned: ";
    cin >> component.branch_name;
    cout << "Enter the branch location: ";
    cin >> component.branch_location;

    components.push_back(component);
    cout << "Hardware component added successfully." << endl;
}

// Function to view all hardware components
void viewHardwareComponents(const vector<HardwareComponent>& components) {
    cout << "\nHardware Component List:" << endl;
    for (const auto& component : components) {
        cout << "ID: " << component.id << ", Name: " << component.name
             << ", Price: " << component.price << ", Branch: " << component.branch_name
             << ", Location: " << component.branch_location << endl;
    }
}

// Function to save all data to files
void saveAllData(const list<Employee>& employees, const stack<ATM>& atms, const queue<Branch>& branches, const vector<HardwareComponent>& hardwareComponents) {
    saveEmployees(employees, "employees.txt");
    saveATMs(atms, "atms.txt");
    saveBranches(branches, "branches.txt");
    saveHardwareComponents(hardwareComponents, "hardware_components.txt");
}

// Function to display the menu
void displayMenu() {
    cout << "\nBank Management System" << endl;
    cout << "1. Add Employee" << endl;
    cout << "2. View All Employees" << endl;
    cout << "3. View Employee by ID" << endl;
    cout << "4. Update Employee Salary" << endl;
    cout << "5. Delete Employee" << endl;
    cout << "6. Add ATM" << endl;
    cout << "7. View All ATMs" << endl;
    cout << "8. Add Branch" << endl;
    cout << "9. View All Branches" << endl;
    cout << "10. Add Hardware Component" << endl;
    cout << "11. View All Hardware Components" << endl;
    cout << "12. Save All Data" << endl;
    cout << "13. Exit" << endl;
    cout << "Enter your choice: ";
}

void administration(){
    list<Employee> employees = loadEmployees("employees.txt");
    stack<ATM> atms = loadATMs("atms.txt");
    queue<Branch> branches = loadBranches("branches.txt");
    vector<HardwareComponent> hardwareComponents = loadHardwareComponents("hardware_components.txt");

    int choice;
    do {
        displayMenu();
        cin >> choice;

        switch (choice) {
            case 1:
                addEmployee(employees, branches);
                break;
            case 2:
                viewEmployees(employees);
                break;
            case 3: {
                int id;
                cout << "Enter employee ID: ";
                cin >> id;
                viewEmployeeByID(employees, id);
                break;
            }
            case 4:
                updateSalary(employees);
                break;
            case 5:
                deleteEmployee(employees);
                break;
            case 6:
                addATM(atms);
                break;
            case 7:
                viewATMs(atms);
                break;
            case 8:
                addBranch(branches);
                break;
            case 9:
                viewBranches(branches);
                break;
            case 10:
                addHardwareComponent(hardwareComponents, branches);
                break;
            case 11:
                viewHardwareComponents(hardwareComponents);
                break;
            case 12:
                saveAllData(employees, atms, branches, hardwareComponents);
                break;
            case 13:
                cout << "Exiting the program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 13);

    return;
}
